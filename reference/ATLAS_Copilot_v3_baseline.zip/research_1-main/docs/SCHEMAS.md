# Artifact contracts, schema version 1

All project files below live in `projects/<id>/`. JSON disallows duplicate keys and nonfinite numeric constants. Use UTF-8. The implementation in `atlas/project.py` and `atlas/evidence.py` is authoritative for required fields. Fields can contain detailed text or references to additional local documents; a reference is not a substitute for the required substantive content.

## State and intake

`state.sqlite3` contains `meta`, `events`, `tasks`, `costs`. Do not edit it manually. The engine owns inquiry, domain, answers, extra questions, state, revision and seal receipts. `mandate.json` is generated from recorded answers and acknowledged assumptions, with `deliverables` as a nonempty description and `paid_budget` as a nonnegative decimal string. Readable assumptions explicitly cover every unanswered essential key. Budget authorization must be established outside the file.

## Preparation dossier and protocol

`dossier.json` contains:

- `methods_compared`: at least two alternatives, including costs, bias, attainable evidence and validity; strings or descriptive objects.
- `selection_reason`, `risks`, `limitations`, `expertise`, `tool_comparison`: substantive text.
- `method_sources`: list of `{url, finding, accessed_at}` for methods independently researched. These are declared records, not automatically authenticated citations. Keep copies/excerpts and bibliography in a companion dossier if needed.
- `pilot`: observed outcomes or precise limitations, never a fabricated successful connection.

`protocol.json` contains nonempty lists `methods`, `coverage` (unique string dimension IDs), `search_plan`, `evaluation_criteria` (predefined metrics and acceptance tests); text `inclusion`, `exclusion`, `verification`, `stopping_rule`, `amendment_policy`; integer `meta_iterations` from 1 to 3. Add `version`, `freshness_policy`, measurement definitions, quantitative analysis, weights, sources, restrictions and predeclared evaluation criteria. The engine bounds preparation passes; it does not evaluate design validity or stop a model from thinking beyond the limit.

`readiness.json` contains `decision` = `ready` or `limited`, `limitations`, and `checks` for `methods`, `evidence`, `tools`, `computation`, `budget`, `verification`, `permissions`. Each check is `{status: passed|limited, basis, fallback?}`; limited checks require a fallback. Missing/blocked checks fail. Optional `capabilities` are observation objects `{name,status,observed_at,expires_at,method,limitations,evidence_artifact?}`. Status = unavailable/discovered/configured/authenticated/tested/failed. Tested/authenticated records need a local evidence artifact. Their content remains operator attestation; no login is performed.

## Orchestration and coverage

`plan.json` = `{architecture_reason, model_policy, tasks:[{id,objective,owner,evidence_required,depends_on:[]}]}`. IDs unique; dependency references must exist; cycles fail. Add actual model identity, permissions and budgets when known. Task runtime status is held transactionally in SQLite. Never put executable shell strings in task objectives for automatic execution.

`coverage.json` = `{items:[{dimension,status:covered|gap,basis,decision_impact?}],stopping_decision}`. Every protocol dimension occurs exactly once; gaps require decision impact. This checks accounting, not whether the search was exhaustive. `search_log.json` = `{queries:[{query,tool,at,outcome}]}`; also include filters, pages, inclusion/exclusion, count semantics, access errors and negative evidence where meaningful.

## Evidence register

`evidence.json` = `{schema_version:1,sources:[],claims:[],assessments:[],calculations:[]}`.

| Object | Required contract |
|---|---|
| Source | `id,url,title,accessed_at,origin_group,snapshot,sha256` |
| Optional source metadata | `published_at,expires_at,data_period,geography,population,method,license,source_type,provenance_note` |
| Claim | `id,text,kind,material,source_ids,author` |
| Assessment | `claim_id,source_id,excerpt,locator,verdict,reasoning,reviewer,reviewer_type,independent,reviewed_at` |
| Calculation | `path,sha256,claim_ids,bindings` (optional `id`) |

Source URL must be public HTTP(S) without credentials, localhost, reserved example/test names or nonpublic literal IPs. The validator **does not fetch or resolve it**, so URL acceptance is not evidence of existence or protection against DNS rebinding in another program. For supplied local evidence, use `source_type: local`, a `local:` identifier and a provenance note. Snapshot must be an existing UTF-8 text file within the project; save a faithful extracted passage when originals are binary or redistribution is restricted. Keep page/section and permitted original file separately. Hashes check stored bytes, not the authenticity of the source. Identical snapshot bytes cannot be labeled as different origin groups. Nonidentical syndicated documents still require manual provenance tracing.

Claim `kind` = factual/numeric/inference. `material` is boolean. Source references are nonempty and resolve. Each material claim needs a supporting assessment with a distinct declared reviewer and `independent:true`. Reviewer type is human/model. Verdict is supports/contradicts/insufficient. Excerpt must match snapshot text exactly; matching does not establish entailment. Every contradictory assessment needs a substantive `resolution` on the claim. The quality of that resolution is a review responsibility. Do not relabel important unsupported claims nonmaterial just to pass; narrow the conclusion or retain a partial result.

All numeric claims need `numeric_value` (decimal string) and `units`. A derived numeric claim also needs a calculation binding. A directly reported statistic may instead use `reported_statistic:true`; this does not waive its independent source review and is not a way to bypass calculation requirements for derived quantities.

A calculation file is the actual JSON produced by `atlas quant`: `{input:<spec>,result:<output>}`. Validation reruns the registered analysis and compares canonical output, then checks each numeric claim binding, for example:

```json
{"id":"M1","path":"calculations/economics.json","sha256":"HASH_FROM_ACTUAL_FILE","claim_ids":["C2"],"bindings":[{"claim_id":"C2","pointer":"/output/contribution_per_order","units":"USD per order"}]}
```

`pointer` is a JSON pointer into `result`, not the whole artifact. Replace the explanatory hash token with a real SHA256; this example is documentation, not a ready-to-pass record. Bindings compare declared numeric values and the generated `output_units` map; the input `units` is the base unit label (for example USD). semantic dimensional consistency and natural-language report numbers still need review. The source of each assumption should be recorded in the quantitative input and claim evidence.

## Audit and synthesis

`review.json` contains nonempty `reviewer,author,counterarguments,uncertainty,coverage_review,numeric_review,limitations`; `independent:true`; `decision:pass|conditional`; `unresolved_critical:[]`. Stale evidence warnings require `freshness_resolution`. Different identity strings do not prove actual independence. Document same-model/cross-model/human scope honestly. An unresolved decision-critical contradiction cannot be waved through by a generic limitation.

`synthesis.json` contains `conclusion,tradeoffs,uncertainty,failure_conditions,strongest_counterargument,claim_ids`. IDs must resolve. The engine does not parse prose to discover hidden unsupported claims. Audit the report against this structured record.

## Delivery, lessons and evaluation

`deliverables.json` = `{contract_review,files:[{path,sha256,format_review,citation_review}]}`. Files must exist, be nonempty and match hashes. Format/citation checks are explicit reviewer attestations; for PDF, slides and spreadsheets perform actual format-specific checks separately and reference them. A renamed extension is not a validated format.

`lessons.json` = `{outcome,proposals:[]}`; the proposals list can intentionally be empty. Active memory entry: `{id,kind:method,method,scope,author,reviewer,expires_at,validation_artifact,validation_sha256,status:validated,tags?:[]}`. Receipt is `{passed:true,tests:[...],limitations:...}`. Use real test receipts; the engine checks presence and hashes, not the reviewer identity or experimental validity.

`evaluation.json` contains nonempty `criteria,results,failures,limitations,next_actions` and `research_quality_proven:false`. `criteria` must exactly match the accepted protocol's `evaluation_criteria`. Use predefined denominators and actual observations. An absence of observed failures is distinct from proof of no failures.
