# Historical testing and benchmark report

> **Historical artifact:** This report describes the pre-Copilot ATLAS release and does not validate the Copilot conversion in this archive. The conversion has not been run or runtime-tested. See [current implementation status](../docs/IMPLEMENTATION_STATUS.md).

Release 3.0.0. Final local run: 2026-11-03T18:46:34.559897+00:00. **126/126 tests passed**, 0 failures, 0 errors, 0 skipped. Local release gate: **QUALIFIED_LOCAL_RELEASE**. These are observed local test outcomes, not a research-accuracy score.

Evidence: [test_results.json](test_results.json), [full unittest log](unittest.log), [paired controls](paired_controls.json), [original baseline](baseline_results.json). Test environment: Python 3.13.5, Linux x86_64, SQLite 3.46.1. Claude executable found: False; Claude executed: **no**. No model API, network request or paid call was made by the test suite. Current external research was performed separately through the available browsing service.

## Executed layers and outcomes

| Layer | Actual execution | Result / boundary |
|---|---|---|
| 1. Structure | Required paths; shipped metadata subset; agent tool/model restrictions; Python AST; strict JSON; internal Markdown targets | 61 checked units; 0 reported errors. Not a complete Claude parser or semantic contradiction detector. |
| 2. Software | State/intake/task/cost/recovery, strict IO, source/claim review records, numerical provenance, method memory | 126/126 tests passed; see individual names/results. |
| 3. Claude compatibility | Documentation comparison and static structure only | Real CLI absent; runtime compatibility unresolved. |
| 4. Interaction | Local init/stop, inquiry/answer persistence, mandate, assumptions and routing metadata | Local functions pass; actual conversation, relevance, conflict resolution and tool requests untested. |
| 5. Methods | Eight distinct domain profiles and synthetic plans reach RESEARCH; six calculator inputs execute | Correct local routing/artifact controls; appropriateness of real model-selected methods unmeasured. |
| 6. Adversarial/failure | Fake/reserved URLs, unmatched excerpts, duplicate IDs/origins, self-review, stale/future data, contradictions, changed calculations/units, absent APIs/fallbacks, path escapes, corrupt DB/checkpoint/ledgers | Expected local failures enforced. Malicious text is inert to Python; this is not a live LLM injection-resistance test. |
| 7. Comparative | 15 paired selected checker cases using pristine original extraction and equivalent new defects | All new outcomes match declared expectations: True. No factual accuracy, cost or research superiority claim. |

## Local interaction coverage

| Required scenario | Evidence and limit |
|---|---|
| Fresh install/readiness/stop | Init prints exact sentence at end and creates no project; failure never prints ready. Real Claude behavior not exercised. |
| Receive inquiry/start clarification | Project starts INTAKE, sequential gates block research; natural-language triggering remains unverified. |
| Thorough relevant interview/deliverables | Core/domain/adaptive question persistence and essential deliverables tested; relevance and phrasing require live review. |
| Partial user answers/end interview | Partial answers survive; essential gaps require explicit assumptions and acknowledgment. Actual user acknowledgment is operator recorded. |
| Conflicting requirements | Human/model procedure and held-out scenario supplied; no automatic contradiction solver. |
| Structured mandate/meta ordering | Saved mandate matches inquiry/answers; absent dossier/protocol blocks later work. |
| Missing tool access | Failed or limited-without-fallback readiness blocks; no automatic connection or billing. |
| Pause/cancel/resume | Persisted holds block CLI changes until explicit resume; external jobs are outside this mechanism. |

## Defects found and corrections

The first 68-test run passed 67 and exposed Decimal scientific notation in the break-even order count; formatting was corrected and the regression retained. A later 94-test run passed 92: two structural/init failures were missing report links while report assembly was incomplete. The completed reports resolved those failures; the final run above is authoritative.

Source/code review also found and corrected an edited-budget path that did not recheck mandate seals, task/cost ledger changes not covered by state receipts, post-reopen task-output integrity, missing explicit critical-review clearance, stale-source resolution, model-invocation-disabled stage skills, output-to-claim unit binding, and post-hoc evaluation criteria changes. These were engineering review findings, not claims of independently observed live Claude failures. Regression tests exercise the corrected boundaries.

One deliberately retained limitation is tested: a real excerpt with an unrelated claim can still pass the mechanical validator if the supplied reviewer record falsely says it supports the claim. The result is labeled `mechanical_consistency_only` and warns about semantic limits. A model or qualified human must actually compare meaning. No passing local script qualifies a citation as substantively verified research.

## Paired control comparison

The comparison keeps the intended defect and local environment constant, adapting the schemas to each repository. The cases are selected adversarial checks, not a random sample and not a statistical estimate of real-world error rate. “Accepted” means the local checker returned success, not that a research system produced a correct conclusion.

| Injected case | Original accepted | Upgraded accepted | Expected interpretation |
|---|---:|---:|---|
| pristine_install | True | True | Paired local-control defect, not live research performance |
| malformed_yaml_frontmatter | True | False | Paired local-control defect, not live research performance |
| invalid_python_payload | True | False | Paired local-control defect, not live research performance |
| missing_required_file | False | False | Paired local-control defect, not live research performance |
| meaningless_policy_payload | True | True | Known semantic limitation; not a valid policy |
| arbitrary_stage | True | False | Paired local-control defect, not live research performance |
| fabricated_source_self_attested_v2 | True | False | Paired local-control defect, not live research performance |
| critical_claim_without_source | True | False | Paired local-control defect, not live research performance |
| blank_claim_identifier | True | False | Paired local-control defect, not live research performance |
| missing_source_reference | False | False | Paired local-control defect, not live research performance |
| duplicate_source_id | False | False | Paired local-control defect, not live research performance |
| unverified_critical_claim | False | False | Paired local-control defect, not live research performance |
| invalid_enums | True | False | Paired local-control defect, not live research performance |
| corrupted_state | False | False | Paired local-control defect, not live research performance |
| empty_completion_artifacts | True | False | Paired local-control defect, not live research performance |

The original already rejects some defects; those are retained rather than advertised as novel. Both structural checkers accept sufficiently long meaningless policy prose, because syntax/file checks cannot establish methodological quality. The new system's substantive review requirement is an operating procedure and independent-review obligation, not a solved semantic detector.

## Formal release disposition

All original files have hash-linked audit rows. The six example calculators execute and the synthetic lifecycle reaches COMPLETE with evidence warnings explicitly identifying fixture data. The local release gate permits packaging only if all mandatory local checks pass. Package integrity/extraction is recorded separately after packaging; it is not inferred from unit tests.

The release is **qualified** because real Claude runtime, authenticated provider tests, independent post-implementation audit, live adversarial model tests and blinded research-quality comparison remain unresolved. The earlier independent prototype auditor completed full-file reading/baseline checks; the parallel specialists subsequently stopped at an account usage limit. The primary author completed the implementation and final checks. This is not a completed independent audit of the upgraded code.

To reproduce: `python3 scripts/validate_release.py`. To exercise a synthetic workflow only: `python3 scripts/demo.py`. For real trials use [the evaluation protocol](../benchmarks/PROTOCOL.md) and [eight cases](../benchmarks/cases.json). The roadmap lists the remaining work.
