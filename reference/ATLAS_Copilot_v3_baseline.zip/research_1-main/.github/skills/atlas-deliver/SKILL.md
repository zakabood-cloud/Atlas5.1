---
name: atlas-deliver
description: Synthesize, validate requested deliverables, consolidate methods and evaluate
---

Read mandate and independent review. Write synthesis.json with conclusion, claim IDs, tradeoffs, uncertainty, failure conditions and strongest counterargument. Advance to DELIVER. Produce the requested outputs in outputs/. Major claims must map to source/claim IDs and reproducible analyses. Check file readability, layout when relevant, citation mapping, units and completeness against the deliverable contract. Write deliverables.json with paths, SHA256 hashes, format review and citation review. Advance to MEMORY.
Write lessons.json: outcome, failures and candidate methodological lessons, or an explained empty proposals list. Never promote a topic finding as general method. The `memory --promote` command needs a validation receipt, independent reviewer and expiry; do not change core code autonomously. Advance to EVALUATE, then write evaluation.json using predefined metrics. Separate unmeasured research quality from tested controls, compare to baseline where fair, log next actions. Advance COMPLETE and present actual artifacts plus remaining limitations. A local COMPLETE state is workflow completion, not proof of factual accuracy.
