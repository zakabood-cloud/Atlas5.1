---
name: atlas-audit
description: Independently audit research support, calculations and coverage
---

Read `methods/VERIFICATION.md` and project evidence directly. Use evidence-reviewer and adversarial-reviewer in fresh contexts if available; record any independence limitation. Reviewers must inspect original source context, not just author summaries. Compare each material claim's scope, units, date, population, causal language and uncertainty with its exact cited passage. Check original origin groups, duplicate content, retractions, missing evidence and contrary findings. Reproduce calculations and trace input assumptions. Reject unsupported claims or rewrite conditionally with explicit scope; never fabricate a supporting excerpt.
Run `python3 -m atlas validate <id>`. Passing proves only mechanical consistency. Write review.json with distinct author/reviewer identities, counterarguments, numerical and coverage review, unresolved critical findings and limitations. Identities are recorded attestations, not authentication. If evidence changes after sealing, `reopen` the appropriate prior work state with a reason and repeat downstream gates. Advance to SYNTHESIS only after substantive review and passing mechanical checks.
