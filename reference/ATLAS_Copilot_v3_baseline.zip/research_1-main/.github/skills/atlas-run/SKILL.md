---
name: atlas-run
description: Orchestrate and execute the prepared research with durable task state
---

Read status, protocol, readiness and `methods/ORCHESTRATION.md`. Build plan.json with a dependency DAG, owners, explicit evidence requirements and model policy. Choose a single researcher for sequential work; independent branches only when they add evidence or challenge. Do not share provisional conclusions with the challenger before its initial analysis. Agent definitions are advisory specializations; use only actually available tools.
Advance to RESEARCH; reserve tasks via `task <id> <task-id> running`, save branch outputs, and mark done with an output path. No simultaneous coordinator writers. Failed tasks get at most three recorded attempts; use provider Retry-After and bounded backoff outside this offline engine. A task ledger does not schedule or launch agents itself.
Record every meaningful query in search_log.json including failed access and negative evidence. Populate source snapshots, evidence.json, calculations and coverage.json. Use `quant` only when its declared assumptions match the question; specialist statistics require separately validated code. Persist raw data as permitted, metadata and hashes. Revisit conflicting explanations and decision-reversing assumptions. Stop per protocol when material coverage is adequate or additional work has low decision value; label access-limited results. Advance to VERIFY only when planned tasks and coverage accounting are complete.
