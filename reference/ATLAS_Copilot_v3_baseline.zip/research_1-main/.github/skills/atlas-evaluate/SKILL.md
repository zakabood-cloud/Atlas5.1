---
name: atlas-evaluate
description: Conduct reproducible research-output evaluations, abstention analysis and regression checks
---
Read `methods/EVALUATION.md` and predefined protocol evaluation criteria. Preserve held-out test cases; never use answers from test keys to tune a method. Use `python3 -m atlas bench-eval` on independently prepared trusted cases. Measure factual accuracy, coverage, citation faithfulness, numerical correctness, independence, uncertainty and cost separately. Run paired ablations when possible. Distinguish actual Copilot-session and live-data evaluations from synthetic unit tests. Do not use self-reported AI confidence as measured forecast calibration. Record methods, source access, results, failures and reproducibility instructions.
