---
name: atlas-discover
description: Discover, test and compare source families and domain-specific research tools after the inquiry interview
---
Use research coverage dimensions from the accepted mandate. First read `methods/TOOL_DISCOVERY.md` and `docs/INTEGRATIONS.md`. Delegate independent source intelligence and integration research when valuable. Generate coverage-driven queries with `python3 -m atlas queries`, record primary-source lineage and investigate counterevidence. Identify tools that have current documented endpoints but do not assume authentication. Conduct only authorized read-only pilots; `scholarly-search --live` requires explicit authorization and may be metered by the provider. Record provider response IDs, accessed timestamps and licensing restrictions. Return a method and tool comparison for meta-research; never silently change an accepted protocol.
