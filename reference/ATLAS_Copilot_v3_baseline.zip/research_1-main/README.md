# ATLAS Research OS 3.0 — GitHub Copilot research control and evidence toolkit

**A repository-ready research workflow for GitHub Copilot**, with a mandatory clarification interview, topic-specific meta-research, specialist agents and skills, local task-state enforcement, evidence and numerical analysis, versioned methods memory, and quality evaluation.

This is a **qualified engineering release**, not proof of superior commercial decisions or exhaustive scientific research. Copilot reads repository guidance from `.github/copilot-instructions.md` and `AGENTS.md`; reusable skills and specialist profiles are in `.github/skills/` and `.github/agents/`.

## First use with Copilot

Add the contents of this folder to the repository where you want ATLAS available. Open that repository in a GitHub Copilot surface that supports repository instructions and agent skills. Then ask:

> Initialize ATLAS according to `AGENTS.md`, run `python3 -m atlas init`, report verified readiness, and stop. Do not research or interview me yet.

When you subsequently provide a research question, Copilot should clarify your objective, essential constraints, and **desired deliverables** before meta-research or topic research. See [Copilot quickstart](docs/V3_QUICKSTART.md), [usage](docs/USAGE.md), [implementation status](docs/IMPLEMENTATION_STATUS.md), and [security](docs/SECURITY.md).

## Local checks

```sh
python3 -m atlas check
python3 -m unittest discover -s tests -q
python3 scripts/demo.py        # synthetic only
```

## Included capabilities

- Source discovery and local BM25 retrieval with coverage and independent-origin diagnostics.
- Pilot-based methodology comparison; trained judgment and independently observed evidence are still necessary.
- Two bounded public bibliographic metadata adapters (Crossref/OpenAlex), **opt-in live only**.
- A dependency-ordered task ledger and deterministic synthetic fixture worker. Copilot performs authorized research in its active agent session; the ledger does not launch a separate model CLI.
- Safer budget reservations, semantic review packets, report citation auditing, source lineage and contradiction detection.
- E-commerce, Monte Carlo latent Gaussian correlation, reverse-stress, and expected-value-of-sample-information calculations.
- Repository-wide Copilot instructions, reusable agent skills, and specialist custom-agent profiles.
- Bounded local document ingestion and full-project restore-to-new-destination backups.

The original ATLAS prototype and earlier engineering reports are retained as historical context. **No live Copilot research session, paid commercial API integration, or externally benchmarked improvement is claimed.** Copilot feature availability and behavior vary by product surface and repository settings; review [implementation status](docs/IMPLEMENTATION_STATUS.md).
