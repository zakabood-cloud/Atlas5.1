# Controlled method memory

Active JSON entries are created only by explicit reviewed promotion through `atlas memory --promote`. No validated lessons are preloaded from this reconstruction. Tests are synthetic control validation, not proof that a research method improves real outcomes. Proposals live with their originating project. Expired entries are excluded from retrieval; version history is retained. This local directory is plaintext and its contents are ignored by Git.
