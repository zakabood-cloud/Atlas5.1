"""Safe local text/document ingestion with explicit modality boundaries.

PDF extraction is optional and text-only. Graphs/images/scanned pages require
separate visual inspection and must never be silently treated as extracted facts.
"""
import csv
import html
import json
import io
from html.parser import HTMLParser
from pathlib import Path
from .io import AtlasError,file_hash

SUPPORTED={'.txt','.md','.csv','.tsv','.json','.html','.htm','.pdf'}
class VisibleText(HTMLParser):
    def __init__(self): super().__init__(); self.hidden=0;self.out=[]
    def handle_starttag(self,tag,attrs):
        if tag.lower() in {'script','style','noscript'}: self.hidden+=1
    def handle_endtag(self,tag):
        if tag.lower() in {'script','style','noscript'} and self.hidden: self.hidden-=1
    def handle_data(self,data):
        if not self.hidden and data.strip(): self.out.append(data)

def ingest(path,max_bytes=10_000_000,max_chars=200_000):
    p=Path(path)
    if p.is_symlink() or not p.is_file(): raise AtlasError('Input must be existing regular nonsymlink file')
    if not 1000<=max_bytes<=50_000_000 or not 1000<=max_chars<=1_000_000: raise AtlasError('Invalid ingestion bounds')
    if p.stat().st_size>max_bytes: raise AtlasError('Source file exceeds ingestion limit')
    suffix=p.suffix.lower()
    if suffix not in SUPPORTED: raise AtlasError('Unsupported format; use an approved specialist reader')
    warnings=[];text='';pages=None
    if suffix=='.pdf':
        try: from pypdf import PdfReader
        except ImportError: raise AtlasError('PDF extraction requires optional pypdf; graphics/scans still require visual inspection')
        r=PdfReader(str(p),strict=True)
        if r.is_encrypted: raise AtlasError('Encrypted PDFs not supported')
        if len(r.pages)>500: raise AtlasError('PDF page count exceeds limit')
        pages=len(r.pages)
        sections=[]
        for i,page in enumerate(r.pages):
            sections.append('[[PDF page %d]]\n%s' % (i+1,(page.extract_text() or '')[:max_chars]))
        text='\n'.join(sections)
        warnings.append('Text extraction misses charts, images, scanned text and meaningful layout; visually audit relevant PDF pages')
    else:
        content=p.read_text(encoding='utf-8-sig',errors='strict')
        if suffix in {'.html','.htm'}:
            parser=VisibleText();parser.feed(content);text='\n'.join(parser.out)
            warnings.append('HTML text does not preserve visual layout or JavaScript-rendered content')
        elif suffix=='.json':
            value=json.loads(content)
            text=json.dumps(value,indent=2,ensure_ascii=False)
        elif suffix in {'.csv','.tsv'}:
            delim=',' if suffix=='.csv' else '\t'
            lines=list(csv.reader(io.StringIO(content),delimiter=delim))
            if len(lines)>100000: raise AtlasError('Too many tabular rows')
            text='\n'.join(' | '.join(row) for row in lines)
            warnings.append('Tabular text view can lose cell formulas/types; use validated structured analysis for numeric claims')
        else: text=content
    if not text.strip(): warnings.append('No extractable text; likely empty or image-only source')
    truncated=len(text)>max_chars
    return {'path':str(p),'sha256':file_hash(p),'source_bytes':p.stat().st_size,
            'format':suffix,'pages':pages,'text':text[:max_chars],'truncated':truncated,
            'warnings':warnings,'verification_level':'content_extraction_only_not_source_authenticity'}
