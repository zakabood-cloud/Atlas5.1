"""Deterministic corpus search, query planning and evidence-coverage diagnostics.

A local lexical engine, NOT a replacement for live retrieval or a semantic model.
No network calls; no executing text found in documents.
"""
import math
import re
from collections import Counter, defaultdict
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode
from .io import AtlasError

STOP = {'the','and','for','with','from','that','this','into','your','are','what','how','will','was','where','which'}
TRACKING = {'fbclid','gclid','msclkid','ref','ref_src'}

def tokenize(text):
    if not isinstance(text,str): raise AtlasError('Search text must be a string')
    return [x for x in re.findall(r'(?u)\b[^\W_]{2,}\b',text.casefold()) if x not in STOP]

def canonical_url(url):
    """Normalizes HTTP(S) references; leaves redirect resolution to a verified fetcher."""
    parts=urlsplit(url)
    if parts.scheme not in {'http','https'} or not parts.hostname or parts.username or parts.password:
        raise AtlasError('Expected valid public HTTP(S) URL')
    host=parts.hostname.lower().rstrip('.')
    if any(c.isspace() for c in host): raise AtlasError('Invalid host')
    port=parts.port
    netloc=host+((':'+str(port)) if port and not (port==80 and parts.scheme=='http') and not (port==443 and parts.scheme=='https') else '')
    query=urlencode(sorted((k,v) for k,v in parse_qsl(parts.query,keep_blank_values=True)
                           if not k.lower().startswith('utm_') and k.lower() not in TRACKING))
    return urlunsplit((parts.scheme,netloc,parts.path.rstrip('/') or '/',query,''))

def expand_queries(question, coverage, synonyms=None, geographies=None, max_queries=80):
    """Coverage-directed query templates; experts/agents should add validated domain terms."""
    if not question.strip() or not coverage: raise AtlasError('Need question and coverage dimensions')
    if not isinstance(max_queries,int) or not 1<=max_queries<=200: raise AtlasError('Invalid query bound')
    synonyms=synonyms or {}; geographies=geographies or []
    concepts=[]
    for dimension in coverage:
        if not isinstance(dimension,str) or not dimension.strip(): raise AtlasError('Invalid coverage dimension')
        variants=[dimension]+synonyms.get(dimension,[])
        for term in variants:
            for geo in (geographies or ['']):
                concepts.append({'dimension':dimension,'query':' '.join(x for x in [question.strip(),term.strip(),geo.strip()] if x),'strategy':'coverage'})
                concepts.append({'dimension':dimension,'query':' '.join(x for x in [term.strip(),geo.strip(),'official statistics data methodology'] if x),'strategy':'primary_source'})
                concepts.append({'dimension':dimension,'query':' '.join(x for x in [term.strip(),geo.strip(),'criticism failure contradictory evidence'] if x),'strategy':'counterevidence'})
    out=[]; seen=set()
    for row in concepts:
        k=row['query'].casefold()
        if k not in seen:
            out.append(row); seen.add(k)
        if len(out)>=max_queries: break
    return out

def bm25_search(query,documents,limit=10,k1=1.2,b=.75):
    """Rank {id,text} local documents. Scores indicate lexical relevance, not factual reliability."""
    if not 1<=limit<=200: raise AtlasError('Invalid limit')
    if not isinstance(documents,list): raise AtlasError('Expected document list')
    index=[]; df=Counter(); ids=set()
    for row in documents:
        if not isinstance(row,dict) or not isinstance(row.get('id'),str) or not isinstance(row.get('text'),str):
            raise AtlasError('Documents need id/text')
        if row['id'] in ids: raise AtlasError('Duplicate document id')
        ids.add(row['id']); tokens=tokenize(row['text']); tf=Counter(tokens)
        for t in tf: df[t]+=1
        index.append((row['id'],tf,len(tokens)))
    n=len(index); avg=sum(length for _,_,length in index)/n if n else 1
    qterms=list(dict.fromkeys(tokenize(query))); scores=[]
    for id_,tf,length in index:
        score=0.
        for term in qterms:
            if term in tf:
                idf=math.log(1+(n-df[term]+.5)/(df[term]+.5))
                score+=idf*tf[term]*(k1+1)/(tf[term]+k1*(1-b+b*length/avg))
        if score>0: scores.append({'id':id_,'score':round(score,8)})
    return sorted(scores,key=lambda x:(-x['score'],x['id']))[:limit]

def coverage_audit(required, observations):
    """Rows must be attached to a dimension and have independent provenance pointers."""
    required=list(required)
    if not required or len(required)!=len(set(required)):
        raise AtlasError('Need unique coverage dimensions')
    known=set(required); found=defaultdict(list); invalid=[]
    for row in observations:
        if not isinstance(row,dict) or row.get('dimension') not in known or not row.get('source_id'):
            invalid.append(row); continue
        found[row['dimension']].append(row)
    result=[]
    for d in required:
        rows=found[d]; origins={r.get('origin_group') or r['source_id'] for r in rows}
        result.append({'dimension':d,'observation_count':len(rows),
                       'distinct_origin_count':len(origins),'source_ids':sorted({r['source_id'] for r in rows}),
                       'status':'uncovered' if not rows else 'single_origin' if len(origins)==1 else 'multiple_origins'})
    return {'dimensions':result,'uncovered':[r['dimension'] for r in result if r['status']=='uncovered'],
            'invalid_observations':len(invalid),
            'warning':'Multiple origins alone do not establish truth or complete recall.'}
