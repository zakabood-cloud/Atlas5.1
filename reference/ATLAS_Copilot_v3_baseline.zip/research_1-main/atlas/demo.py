"""Synthetic integration fixture: never presented as an external research outcome."""
from .project import Project
from .intake import questions
from .io import atomic_json, file_hash, now


def evidence_fixture(path):
    p=path/"sources/fixture.txt"; p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text("Synthetic fixture only. The observed count is ten.\n",encoding="utf-8")
    stamp=now()
    return {"schema_version":1,
      "sources":[{"id":"S1","source_type":"local","url":"local:synthetic-fixture","title":"Synthetic fixture",
      "provenance_note":"Created for deterministic local testing; not independently observed world data",
      "accessed_at":stamp,"origin_group":"fixture-1","snapshot":"sources/fixture.txt","sha256":file_hash(p)}],
      "claims":[{"id":"C1","text":"The synthetic fixture reports a count of ten.","kind":"factual","material":True,"source_ids":["S1"],"author":"fixture-author"}],
      "assessments":[{"claim_id":"C1","source_id":"S1","excerpt":"The observed count is ten.","locator":"line 1","verdict":"supports",
      "reasoning":"Exact statement in fixture; tests plumbing only, not human semantic review.","reviewer":"fixture-reviewer","reviewer_type":"model","independent":True,"reviewed_at":stamp}],
      "calculations":[]}


def prepare_research(root,slug="demo",domain="general"):
    p=Project.create(root,slug,"Synthetic lifecycle demonstration; no external research",domain)
    for q in questions(root,domain):
        p.answer(q["key"],"Synthetic declared answer; this is not a user preference.")
    p.mandate(acknowledged=True)
    p.advance("MANDATE"); p.advance("META")
    atomic_json(p.path/"dossier.json",{"methods_compared":["Structured source review","Unstructured summary"],"selection_reason":"Fixture chooses explicit provenance",
      "risks":"Synthetic test cannot establish research quality","limitations":"No live API or model","expertise":"Local engineering test","tool_comparison":"No network versus unavailable paid sources",
      "method_sources":[{"url":"https://www.prisma-statement.org/prisma-2020-statement","finding":"Reference label only in synthetic fixture; production dossier requires actual research","accessed_at":now()}],
      "pilot":"Synthetic source import and hash test"})
    atomic_json(p.path/"protocol.json",{"methods":["Synthetic source inspection"],"coverage":["fixture_support"],"search_plan":["Read local fixture"],"inclusion":"Synthetic fixture only",
      "exclusion":"All actual world conclusions","verification":"Compare exact phrase and hash","stopping_rule":"Fixture processed","amendment_policy":"Record reopen reason","meta_iterations":1,"evaluation_criteria":["Valid local control path; no research accuracy claim"]})
    p.advance("READINESS")
    atomic_json(p.path/"readiness.json",{"decision":"limited","checks":{k:{"status":"limited","basis":"Local synthetic fixture only","fallback":"No external claims"} for k in ["methods","evidence","tools","computation","budget","verification","permissions"]},"capabilities":[],"limitations":"Not a Copilot runtime test"})
    p.advance("ORCHESTRATE")
    atomic_json(p.path/"plan.json",{"architecture_reason":"Single deterministic fixture","model_policy":"No model invoked","tasks":[{"id":"collect","objective":"Inspect fixture","owner":"test-runner","evidence_required":"Snapshot and excerpt","depends_on":[]}]})
    p.advance("RESEARCH")
    return p


def complete(root,slug="demo"):
    p=prepare_research(root,slug)
    data=evidence_fixture(p.path); atomic_json(p.path/"evidence.json",data)
    p.task("collect","running")
    (p.path/"branches/collect.md").write_text("Synthetic fixture inspected; not external research.\n")
    p.task("collect","done","branches/collect.md")
    atomic_json(p.path/"coverage.json",{"items":[{"dimension":"fixture_support","status":"covered","basis":"Synthetic support path exercised"}],"stopping_decision":"Fixture complete"})
    atomic_json(p.path/"search_log.json",{"queries":[{"query":"Synthetic fixture","tool":"local file","at":now(),"outcome":"One synthetic record; no web research"}]})
    p.advance("VERIFY")
    atomic_json(p.path/"review.json",{"author":"fixture-author","reviewer":"fixture-reviewer","independent":True,"decision":"conditional","unresolved_critical":[],"counterarguments":"No factual capability measured","uncertainty":"Synthetic only","coverage_review":"One fixture","numeric_review":"No numeric derivation","limitations":"Review identity is fixture data, not a real independent person or model"})
    p.advance("SYNTHESIS")
    atomic_json(p.path/"synthesis.json",{"conclusion":"Synthetic pipeline completed","tradeoffs":"Fixture only","uncertainty":"No generalization measured","failure_conditions":"Invalid artifacts block transitions","strongest_counterargument":"Real research may fail despite passing local gates","claim_ids":["C1"]})
    p.advance("DELIVER")
    out=p.path/"outputs/demo-report.md"; out.write_text("# Synthetic lifecycle demonstration\n\nThis is a test fixture. It does not establish external research performance.\n\nClaim C1: the fixture reports a count of ten (S1, local fixture, line 1).\n")
    atomic_json(p.path/"deliverables.json",{"contract_review":"Synthetic one-file contract fulfilled","files":[{"path":"outputs/demo-report.md","sha256":file_hash(out),"format_review":"Markdown read","citation_review":"C1 maps to S1; synthetic"}]})
    p.advance("MEMORY")
    atomic_json(p.path/"lessons.json",{"outcome":"Synthetic flow only; no reusable empirical lesson","proposals":[]})
    p.advance("EVALUATE")
    atomic_json(p.path/"evaluation.json",{"criteria":["Valid local control path; no research accuracy claim"],"results":"Local control path exercised","failures":"None in fixture run","limitations":"No Copilot or external research","next_actions":"Run authorized real session and blinded evaluation","research_quality_proven":False})
    p.advance("COMPLETE")
    return p
