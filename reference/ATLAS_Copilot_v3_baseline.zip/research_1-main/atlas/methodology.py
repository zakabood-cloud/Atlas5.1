"""Pre-registered methodology comparison and measured small-pilot selection."""
from .io import AtlasError

DEFAULT_WEIGHTS={'evidence_quality':.30,'coverage':.25,'reproducibility':.20,'feasibility':.15,'cost_efficiency':.10}

def score_methods(candidates,weights=None):
    """Score pilot observations on a declared [0,1] rubric; return complete audit trail."""
    weights=weights or DEFAULT_WEIGHTS
    if not isinstance(weights,dict) or not weights or any(not 0<=float(w)<=1 for w in weights.values()) or sum(map(float,weights.values()))<=0:
        raise AtlasError('Invalid method weights')
    if len(candidates)<2: raise AtlasError('Compare at least two candidate methodologies')
    names=set(); output=[]
    for method in candidates:
        if not isinstance(method,dict) or not method.get('name') or method['name'] in names: raise AtlasError('Duplicate or missing method name')
        names.add(method['name']); observed=method.get('pilot',{})
        if set(weights)-set(observed): raise AtlasError('Missing pilot dimension for '+method['name'])
        for k in weights:
            if type(observed[k]) not in (int,float) or not 0<=observed[k]<=1: raise AtlasError('Pilot scores must be [0,1]')
        if not method.get('pilot_evidence'): raise AtlasError('Pilot evidence required')
        score=sum(float(weights[k])*observed[k] for k in weights)/sum(map(float,weights.values()))
        output.append({'name':method['name'],'score':round(score,6),'pilot':observed,
                       'pilot_evidence':method['pilot_evidence'],'limitations':method.get('limitations',[])})
    output.sort(key=lambda x:(-x['score'],x['name']))
    return {'ranking':output,'selected':output[0]['name'],'weights':weights,
            'caveat':'Pilot scoring compares observed task samples, not universal superiority. Preserve original methodology and amend transparently.'}
