"""Durable task-ledger dispatch using a deterministic synthetic fixture worker.

Real research is performed in the active Copilot agent session and recorded through
the project ledger; this module does not launch a separate model CLI.
"""
import asyncio
import re
from .io import AtlasError, confined, atomic_json, now


class FixtureWorker:
    async def execute(self,task,context):
        return {'task_id':task['id'],'response':'Fixture completed '+task['objective'],
                'worker':'fixture','observed_at':now(),
                'warning':'Synthetic test only, NOT a research result'}


async def run_ready(project,worker,max_workers=2,max_tasks=100):
    """Runs pending DAG nodes and records outputs. Failures become FAILED; no retry spam."""
    if not 1<=max_workers<=8 or not 1<=max_tasks<=1000: raise AtlasError('Invalid work bounds')
    status=project.status()
    if status['state']!='RESEARCH' or status.get('hold'): raise AtlasError('Project must be active RESEARCH')
    mandate=project.artifact('mandate.json'); count=0; completed=[]; failed=[]
    sem=asyncio.Semaphore(max_workers)
    async def one(task):
        async with sem:
            project.task(task['id'],'running')
            try:
                result=await worker.execute(task,{'cwd':str(project.root),'mandate':str(mandate)})
                if result.get('task_id')!=task['id']: raise AtlasError('Worker returned wrong task ID')
                path=f"branches/{task['id']}.json"
                if not re.fullmatch(r'[a-zA-Z0-9_-]{1,80}',task['id']): raise AtlasError('Unsafe task ID')
                atomic_json(confined(project.path,path),result)
                project.task(task['id'],'done',path); completed.append(task['id'])
            except Exception as e:
                project.task(task['id'],'failed')
                failed.append({'id':task['id'],'error':type(e).__name__+': '+str(e)[:200]})
    while count<max_tasks:
        status=project.status()
        done={t['id'] for t in status['tasks'] if t['status']=='done'}
        ready=[t for t in status['tasks'] if t['status']=='pending' and all(dep in done for dep in t['depends_on'])]
        if not ready: break
        batch=ready[:min(max_workers,max_tasks-count)]
        await asyncio.gather(*(one(t) for t in batch))
        count+=len(batch)
    last=project.status()
    return {'completed':completed,'failed':failed,'remaining':[t['id'] for t in last['tasks'] if t['status']!='done'],
            'state':last['state'],'note':'Research outputs require source/citation and substantive verification before any conclusions'}
