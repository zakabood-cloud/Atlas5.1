"""Versioned method memory, separate from topic evidence and never executable."""
import re
from pathlib import Path
from .io import AtlasError, confined, read_json, atomic_json, file_hash, date, now, text_required


def promote(root,proposal):
    root=Path(root)
    if not isinstance(proposal,dict): raise AtlasError("Memory proposal must be object")
    for k in ["id","method","scope","author","reviewer","expires_at","validation_artifact","validation_sha256"]: text_required(proposal,k)
    if not re.fullmatch(r"[a-z0-9-]{1,64}",proposal["id"]): raise AtlasError("Invalid memory ID")
    if proposal.get("kind")!="method" or proposal.get("status")!="validated": raise AtlasError("Only validated methods enter active memory")
    if proposal["author"]==proposal["reviewer"]: raise AtlasError("Distinct reviewer required")
    if date(proposal["expires_at"])<=date(now()): raise AtlasError("Memory expires in past")
    p=confined(root,proposal["validation_artifact"],True)
    if file_hash(p)!=proposal["validation_sha256"]: raise AtlasError("Validation receipt changed")
    receipt=read_json(p)
    if receipt.get("passed") is not True or not receipt.get("tests") or not receipt.get("limitations"):
        raise AtlasError("Validation receipt must contain passed=true, tests, and limitations")
    dest=confined(root,"memory/"+proposal["id"]+".json")
    previous=read_json(dest) if dest.exists() else None
    version=previous["version"]+1 if previous else 1
    if previous:
        atomic_json(confined(root,f"memory/history/{proposal['id']}-v{previous['version']}.json"),previous)
    out=dict(proposal,version=version,promoted_at=now())
    atomic_json(dest,out)
    return out


def retrieve(root,query="",as_of=None):
    current=date(as_of or now()); rows=[]
    for p in sorted((Path(root)/"memory").glob("*.json")):
        if p.is_symlink(): continue
        row=read_json(p)
        if row.get("status")!="validated" or date(row["expires_at"])<current: continue
        if query and query.lower() not in (row["method"]+" "+row["scope"]+" "+" ".join(row.get("tags",[]))).lower(): continue
        rows.append(row)
    return rows
