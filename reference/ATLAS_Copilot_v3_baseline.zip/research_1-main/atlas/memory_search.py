"""Structured and lexical retrieval over validated, non-expired method memory."""
from pathlib import Path
from .io import date, now, read_json
from .retrieval import bm25_search, tokenize

def retrieve_ranked(root,query='',scope=None,tags=None,limit=15):
    rows=[]; current=date(now()); tags=set(tags or [])
    for p in (Path(root)/'memory').glob('*.json'):
        if p.is_symlink(): continue
        try: row=read_json(p)
        except (OSError,ValueError): continue
        if row.get('status')!='validated' or date(row['expires_at'])<current: continue
        if scope and scope not in row.get('scope',''): continue
        if tags and not tags.intersection(set(row.get('tags',[]))): continue
        rows.append(row)
    if not query: return rows[:limit]
    scored=bm25_search(query,[{'id':r['id'],'text':' '.join([r.get('method',''),r.get('scope','')]+r.get('tags',[]))} for r in rows],limit=limit)
    lookup={r['id']:r for r in rows}
    return [dict(lookup[s['id']],retrieval_score=s['score']) for s in scored]
