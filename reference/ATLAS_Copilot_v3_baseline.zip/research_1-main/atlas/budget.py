"""Transactional preflight reservations for optional external calls.

Cannot enforce provider-side billing; caller must reserve BEFORE dispatch and
settle only after use. All amounts are declared estimated USD, not invoices.
"""
import sqlite3
from decimal import Decimal
from pathlib import Path
from .io import AtlasError, now
from .quant import nonnegative

class Budget:
    def __init__(self,path,limit):
        self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)
        self.limit=nonnegative(limit)
        with self._connect() as db:
            db.execute('''CREATE TABLE IF NOT EXISTS reservations (
                key TEXT PRIMARY KEY, estimated TEXT NOT NULL, actual TEXT,
                status TEXT NOT NULL, authorized_at TEXT NOT NULL, provider TEXT NOT NULL)''')
    def _connect(self):
        db=sqlite3.connect(self.path,timeout=10,isolation_level=None)
        db.execute('PRAGMA busy_timeout=10000')
        return db
    def _totals(self,db):
        committed=Decimal('0'); reserved=Decimal('0')
        for est,actual,status in db.execute('SELECT estimated,actual,status FROM reservations'):
            if status=='settled': committed+=Decimal(actual)
            elif status=='reserved': reserved+=Decimal(est)
        return committed,reserved
    def reserve(self,key,estimated,provider,authorized=False):
        amount=nonnegative(estimated)
        if not authorized: raise AtlasError('Explicit paid-tool authorization required')
        if not key or not provider: raise AtlasError('Reservation key/provider required')
        with self._connect() as db:
            db.execute('BEGIN IMMEDIATE')
            existing=db.execute('SELECT estimated,provider,status FROM reservations WHERE key=?',(key,)).fetchone()
            if existing:
                if existing[0]!=str(amount) or existing[1]!=provider: raise AtlasError('Idempotency-key conflict')
                db.execute('COMMIT'); return {'key':key,'status':existing[2],'idempotent':True}
            committed,reserved=self._totals(db)
            if amount+committed+reserved>self.limit: raise AtlasError('Estimated call exceeds remaining authorization')
            db.execute('INSERT INTO reservations VALUES (?,?,?,?,?,?)',(key,str(amount),None,'reserved',now(),provider))
            db.execute('COMMIT')
        return {'key':key,'status':'reserved','estimated_usd':str(amount)}
    def settle(self,key,actual):
        amount=nonnegative(actual)
        with self._connect() as db:
            db.execute('BEGIN IMMEDIATE')
            row=db.execute('SELECT estimated,actual,status FROM reservations WHERE key=?',(key,)).fetchone()
            if not row: raise AtlasError('Unknown reservation')
            if row[2]=='settled':
                if row[1]!=str(amount): raise AtlasError('Settlement conflict')
            elif row[2]!='reserved': raise AtlasError('Cannot settle canceled reservation')
            else:
                committed,reserved=self._totals(db)
                if committed+reserved-Decimal(row[0])+amount>self.limit: raise AtlasError('Actual cost exceeds authorized ceiling; halt provider work')
                db.execute('UPDATE reservations SET actual=?,status=? WHERE key=?',(str(amount),'settled',key))
            db.execute('COMMIT')
        return self.status()
    def cancel(self,key):
        with self._connect() as db:
            db.execute('BEGIN IMMEDIATE')
            row=db.execute('SELECT status FROM reservations WHERE key=?',(key,)).fetchone()
            if not row or row[0]!='reserved': raise AtlasError('Only active reservations can be canceled')
            db.execute('UPDATE reservations SET status=? WHERE key=?',('canceled',key)); db.execute('COMMIT')
        return self.status()
    def status(self):
        with self._connect() as db: committed,reserved=self._totals(db)
        return {'budget_usd':str(self.limit),'settled_usd':str(committed),'reserved_usd':str(reserved),
                'remaining_usd':str(self.limit-committed-reserved),
                'limit':'local call authorization only; provider-side spending must also be controlled'}
