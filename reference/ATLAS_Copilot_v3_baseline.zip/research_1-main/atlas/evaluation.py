"""Traceable evaluation with abstentions; compares outcomes, not subjective report length."""
from .io import AtlasError

def evaluate_cases(cases,results):
    """Results may include truth labels; missing answers counted as abstentions, not correct."""
    if not cases: raise AtlasError('Need test cases')
    byid={r['id']:r for r in results}; score=[]; correct=answered=0
    for c in cases:
        if 'id' not in c or 'expected' not in c: raise AtlasError('Case needs id and expected')
        r=byid.get(c['id'],{}); prediction=r.get('answer'); responded=prediction is not None
        hit=responded and prediction==c['expected']
        answered+=bool(responded); correct+=bool(hit)
        score.append({'id':c['id'],'answered':responded,'correct':bool(hit),'expected':c['expected'],
                      'prediction':prediction,'evidence':r.get('evidence',[])})
    return {'cases':len(cases),'coverage_rate':answered/len(cases),'accuracy_over_all':correct/len(cases),
            'accuracy_on_answered':correct/answered if answered else None,'per_case':score,
            'warning':'Accuracy depends on trusted independently verified expected answers; does not establish decision profitability.'}

def compare_runs(left,right):
    """Paired answer comparison. No false p values on tiny samples."""
    la={c['id']:c for c in left['per_case']}; ra={c['id']:c for c in right['per_case']}
    common=sorted(set(la)&set(ra))
    if not common: raise AtlasError('No paired cases')
    out={'left_only_correct':[],'right_only_correct':[],'both_correct':[],'neither_correct':[]}
    for i in common:
        a,b=la[i]['correct'],ra[i]['correct']
        out['both_correct' if a and b else 'left_only_correct' if a else 'right_only_correct' if b else 'neither_correct'].append(i)
    return {'paired_cases':len(common),**out,
            'note':'Descriptive paired comparison; independent holdout and expert adjudication required for stronger claims.'}
