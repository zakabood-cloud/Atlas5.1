"""Original-origin dependency graph; no number of URLs can prove source independence."""
from collections import defaultdict
from .io import AtlasError

def group_origins(sources):
    """Cluster by declared origin and obvious duplicate stable IDs/content hash."""
    parent={s['id']:s['id'] for s in sources}
    def find(x):
        while parent[x]!=x:
            parent[x]=parent[parent[x]];x=parent[x]
        return x
    def union(a,b): parent[find(b)]=find(a)
    refs={}
    for s in sources:
        sid=s['id']
        for key in ('origin_group','sha256','doi','dataset_id','original_publication_id'):
            val=s.get(key)
            if not val: continue
            k=(key,val)
            if k in refs: union(sid,refs[k])
            else: refs[k]=sid
    groups=defaultdict(list)
    for s in sources: groups[find(s['id'])].append(s['id'])
    return {'groups':[sorted(ids) for ids in groups.values()],
            'distinct_origin_clusters':len(groups),
            'limitation':'Undetected syndication and shared underlying datasets can remain; requires independent tracing'}

def contradictions(evidence):
    """Expose claims that have positive and negative assessments; does not adjudicate truth."""
    by=defaultdict(lambda:defaultdict(set))
    for a in evidence.get('assessments',[]):
        if a.get('verdict') in ('supports','contradicts','insufficient'):
            by[a.get('claim_id')][a['verdict']].add(a.get('source_id'))
    return [{'claim_id':c,'supporters':sorted(v['supports']),
             'contradictions':sorted(v['contradicts'])} for c,v in by.items()
            if v['supports'] and v['contradicts']]
