"""Whole-project portable backup with secure extraction and SHA-256 manifest.

Caller must ensure no concurrent writers/external jobs. Restore creates a NEW
project destination; never overwrites active research.
"""
import json
import os
import zipfile
from pathlib import Path,PurePosixPath
from .io import AtlasError,file_hash,canonical,now

def backup(project_dir,archive,quiesced=False):
    source=Path(project_dir).resolve(); archive=Path(archive).resolve()
    if not quiesced: raise AtlasError('Quiesce project writers and external jobs before backup')
    if not source.is_dir() or not (source/'state.sqlite3').is_file(): raise AtlasError('Not an ATLAS project')
    if archive.is_relative_to(source): raise AtlasError('Backup destination must be outside project')
    entries=[]
    for p in sorted(source.rglob('*')):
        if p.is_symlink(): raise AtlasError('Symlink in project backup')
        if not p.is_file(): continue
        rel=p.relative_to(source).as_posix()
        if p.stat().st_size>100_000_000: raise AtlasError('File too large for safe backup')
        entries.append({'path':rel,'size':p.stat().st_size,'sha256':file_hash(p)})
    receipt={'schema_version':1,'created_at':now(),'files':entries,
             'limitation':'Operator attests quiescence; not an atomic snapshot of concurrent external writers'}
    archive.parent.mkdir(parents=True,exist_ok=True)
    if archive.exists(): raise AtlasError('Will not overwrite previous backup')
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
        z.writestr('MANIFEST.json',canonical(receipt))
        for row in entries: z.write(source/row['path'],'PROJECT/'+row['path'])
    return {'archive':str(archive),'sha256':file_hash(archive),'files':len(entries)}

def restore(archive,new_project_dir):
    archive=Path(archive).resolve();target=Path(new_project_dir).resolve()
    if target.exists(): raise AtlasError('Restore requires a nonexistent destination')
    with zipfile.ZipFile(archive) as z:
        members=z.namelist()
        if len(members)!=len(set(members)) or 'MANIFEST.json' not in members: raise AtlasError('Invalid project archive')
        receipt=json.loads(z.read('MANIFEST.json'))
        expected={r['path']:r for r in receipt['files']}
        actual=set()
        for item in z.infolist():
            if item.filename=='MANIFEST.json': continue
            rel=item.filename.removeprefix('PROJECT/')
            p=PurePosixPath(rel)
            if not item.filename.startswith('PROJECT/') or not rel or p.is_absolute() or '..' in p.parts or ':' in rel or '\\' in rel:
                raise AtlasError('Unsafe archive member')
            if item.file_size>100_000_000 or rel not in expected: raise AtlasError('Undeclared/oversized archive member')
            # symlink in zip unix flags
            if (item.external_attr>>16)&0o170000==0o120000: raise AtlasError('Symlink member not allowed')
            actual.add(rel)
        if actual!=set(expected): raise AtlasError('Backup manifest and contents differ')
        target.mkdir(parents=True)
        try:
            for rel in sorted(actual):
                row=expected[rel]; dst=target/rel;dst.parent.mkdir(parents=True,exist_ok=True)
                data=z.read('PROJECT/'+rel)
                if len(data)!=row['size']: raise AtlasError('Backup size mismatch')
                dst.write_bytes(data)
                if file_hash(dst)!=row['sha256']: raise AtlasError('Backup hash mismatch')
        except Exception:
            import shutil
            shutil.rmtree(target)
            raise
    return {'restored_path':str(target),'files':len(actual),'warning':'Restore is a copy; review secrets and revalidate source/tool access before use'}
