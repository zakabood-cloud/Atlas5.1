"""Explicitly allowlisted, read-only scholarly metadata retrieval.

Network calls are opt-in. This is *not* a blanket web browser nor a commercial
research integration; sources are metadata and may contain inaccurate abstracts.
"""
import json
import ipaddress
import socket
import time
from urllib.parse import urlencode, urlsplit
from urllib.request import build_opener, Request, HTTPRedirectHandler
from urllib.error import HTTPError, URLError
from .io import AtlasError, now

HOSTS={'crossref':'api.crossref.org','openalex':'api.openalex.org'}
class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        raise AtlasError('External provider redirect blocked; inspect new endpoint manually')

def _allowed(url,provider):
    parsed=urlsplit(url)
    if parsed.scheme!='https' or parsed.hostname!=HOSTS.get(provider) or parsed.username or parsed.password or parsed.port:
        raise AtlasError('URL is not on exact provider allowlist')
    if not parsed.path.startswith('/works') or '..' in parsed.path:
        raise AtlasError('Endpoint not permitted')
    return parsed.hostname

def http_json(url,provider,timeout=15,opener=None):
    _allowed(url,provider)
    if not 1<=timeout<=60: raise AtlasError('Invalid timeout')
    # No user-provided arbitrary destination, no redirects, no cookies or secrets.
    client=opener or build_opener(NoRedirect())
    try:
        with client.open(Request(url,headers={'Accept':'application/json','User-Agent':'ATLAS-Research-OS/3.0 (read-only metadata retrieval)'}),timeout=timeout) as rsp:
            if getattr(rsp,'status',200)!=200: raise AtlasError('Provider returned non-200 response')
            if len(rsp.headers.get('Content-Length','')) and int(rsp.headers.get('Content-Length','0'))>3_000_000:
                raise AtlasError('Provider response too large')
            raw=rsp.read(3_000_001)
            if len(raw)>3_000_000: raise AtlasError('Provider response too large')
            return json.loads(raw.decode('utf-8'))
    except (HTTPError,URLError,TimeoutError,UnicodeError,ValueError) as e:
        raise AtlasError('Provider retrieval failed: '+type(e).__name__) from e

def search(provider,query,limit=10,**kwargs):
    """Return searchable metadata with raw title/DOI/URL; not independently verified full text."""
    if provider not in HOSTS: raise AtlasError('No adapter for provider')
    if not isinstance(query,str) or not query.strip() or len(query)>400: raise AtlasError('Query required (max 400 characters)')
    if type(limit) is not int or not 1<=limit<=50: raise AtlasError('Search limit must be 1..50')
    params={'query.bibliographic':query,'rows':str(limit)} if provider=='crossref' else {'search':query,'per_page':str(limit)}
    url=f'https://{HOSTS[provider]}/works?'+urlencode(params)
    data=http_json(url,provider,**kwargs)
    items=data.get('message',{}).get('items',[]) if provider=='crossref' else data.get('results',[])
    if not isinstance(items,list): raise AtlasError('Unexpected provider schema')
    out=[]
    for item in items[:limit]:
        if not isinstance(item,dict): continue
        title=item.get('title')
        if isinstance(title,list): title=title[0] if title else ''
        title=title or item.get('display_name') or ''
        doi=item.get('DOI') or item.get('doi') or ''
        uri=item.get('URL') or item.get('id') or ''
        out.append({'title':str(title)[:600],'doi':doi,'url':uri,
                    'publication_year':item.get('publication_year'),
                    'source_type':'external_bibliographic_metadata',
                    'note':'Record metadata, NOT verified claim support or complete article text'})
    return {'provider':provider,'query':query,'requested_url':url,'observed_at':now(),
            'items':out,'total_returned':len(out),'retrieval_type':'live_if_called',
            'limitations':'Metadata coverage, indexing delays and provider estimates must be assessed'}
