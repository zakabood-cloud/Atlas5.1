"""ATLAS Research OS: audited local controls and consented optional metadata requests."""
__version__ = "3.0.0"
