"""Repository structure checks using an intentionally restricted YAML frontmatter subset."""
import ast
import re
from pathlib import Path
from .io import read_json, AtlasError

REQUIRED=["AGENTS.md",".github/copilot-instructions.md","README.md","pyproject.toml","methods/domains.json","docs/USAGE.md","docs/SCHEMAS.md","docs/SECURITY.md",
          "atlas/__main__.py","atlas/project.py","atlas/evidence.py","atlas/quant.py","atlas/memory.py",
          ".github/skills/atlas-init/SKILL.md",".github/skills/atlas-research/SKILL.md",
          ".github/skills/atlas-meta/SKILL.md",".github/skills/atlas-run/SKILL.md",
          ".github/skills/atlas-audit/SKILL.md",".github/skills/atlas-deliver/SKILL.md",
          ".github/skills/atlas-discover/SKILL.md",".github/skills/atlas-evaluate/SKILL.md",
          "atlas/__init__.py","atlas/io.py","atlas/intake.py","atlas/integrations.py",
          "atlas/structure.py","atlas/demo.py","scripts/demo.py","docs/INTEGRATIONS.md"]
REQUIRED += [".github/agents/"+name+".agent.md" for name in
             ["methodology-architect","domain-researcher","evidence-reviewer","adversarial-reviewer",
              "quantitative-analyst","source-intelligence-researcher","tool-integration-architect"]]


def frontmatter(path):
    text=Path(path).read_text(encoding="utf-8")
    if not text.startswith("---\n") or "\n---\n" not in text[4:]: raise AtlasError("Missing YAML frontmatter")
    header,body=text[4:].split("\n---\n",1); data={}
    for line in header.splitlines():
        match=re.fullmatch(r"([A-Za-z][A-Za-z0-9_-]*): (.+)",line)
        if not match: raise AtlasError("Use single-line YAML scalars in shipped definitions")
        key,value=match.groups()
        if key in data or value.startswith(("[","{","|",">","&","*","!")): raise AtlasError("Duplicate key or unsupported YAML structure")
        if ": " in value or " #" in value: raise AtlasError("Ambiguous unquoted YAML value")
        data[key]=value
    if not body.strip(): raise AtlasError("Empty instructions")
    if not re.fullmatch(r"[a-z0-9-]+",data.get("name","")) or not data.get("description"): raise AtlasError("Missing valid name/description")
    return data


def check(root):
    root=Path(root); errors=[]; count=0
    if (root/"CLAUDE.md").exists() or (root/".claude").exists():
        errors.append("Claude-specific active configuration is not supported")
    for name in REQUIRED:
        if not (root/name).is_file() or (root/name).stat().st_size==0: errors.append("Missing/empty "+name)
    for p in list((root/"atlas").glob("*.py"))+list((root/"scripts").glob("*.py"))+list((root/"tests").glob("*.py")):
        try: ast.parse(p.read_text(encoding="utf-8")); count+=1
        except SyntaxError as e: errors.append(str(p.relative_to(root))+": "+str(e))
    for p in list((root/".github/agents").glob("*.agent.md"))+list((root/".github/skills").glob("*/SKILL.md")):
        try:
            d=frontmatter(p); count+=1
            if ".github/skills/" in p.as_posix():
                if d["name"]!=p.parent.name: raise AtlasError("Skill directory/name mismatch")
                if "allowed-tools" in d: raise AtlasError("Shipped skills must not grant permissions")
            else:
                agent_name=p.name.removesuffix(".agent.md")
                if d["name"]!=agent_name: raise AtlasError("Agent filename/name mismatch")
                if d.get("permissionMode")=="bypassPermissions": raise AtlasError("Permission bypass forbidden")
                if "memory" in d: raise AtlasError("Use controlled method memory, not automatic reviewer write access")
        except AtlasError as e: errors.append(str(p.relative_to(root))+": "+str(e))
    for folder in ["config","methods","examples"]:
        for p in (root/folder).rglob("*.json"):
            try: read_json(p); count+=1
            except (AtlasError,OSError) as e: errors.append(str(p.relative_to(root))+": "+str(e))
    for p in root.rglob("*.md"):
        if set(p.relative_to(root).parts)&{"projects","reference",".git",".atlas","__pycache__"}: continue
        if not p.exists(): continue
        text=p.read_text(encoding="utf-8")
        for target in re.findall(r"\[[^\]]*\]\(([^)]+)\)",text):
            if "://" in target or target.startswith("#"): continue
            target=target.split("#")[0]
            if target and not (p.parent/target).exists(): errors.append("Broken link "+str(p.relative_to(root))+" -> "+target)
    p=root/"AGENTS.md"
    if p.exists() and len(p.read_text(encoding="utf-8").splitlines())>=200: errors.append("AGENTS.md context budget exceeded")
    return {"ok":not errors,"checked_units":count,"errors":errors,
            "scope":"Static subset validation, Python AST and local references; not Copilot runtime or semantic instruction validation."}
