#!/usr/bin/env python3
"""Repeatable local release gate. Writes evidence; never calls Copilot or a network API."""
import contextlib
import importlib.util
import io
import json
import platform
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from atlas import __version__
from atlas.io import atomic_json, read_json, file_hash, now
from atlas.structure import check
from atlas.quant import run_analysis
from atlas.integrations import discover_capabilities
from atlas.demo import complete

ROOT=Path(__file__).resolve().parents[1]


class RecordedResult(unittest.TextTestResult):
    def startTest(self,test): super().startTest(test); self.started=time.perf_counter()
    def addSuccess(self,test): super().addSuccess(test); records.append({'test':test.id(),'status':'passed','seconds':time.perf_counter()-self.started})
    def addFailure(self,test,err): super().addFailure(test,err); records.append({'test':test.id(),'status':'failed','detail':self._exc_info_to_string(err,test)})
    def addError(self,test,err): super().addError(test,err); records.append({'test':test.id(),'status':'error','detail':self._exc_info_to_string(err,test)})
    def addSkip(self,test,reason): super().addSkip(test,reason); records.append({'test':test.id(),'status':'skipped','reason':reason})


def run():
    started=now(); t0=time.perf_counter(); structure=check(ROOT)
    stream=io.StringIO(); suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'))
    result=unittest.TextTestRunner(stream=stream,verbosity=2,resultclass=RecordedResult).run(suite)
    (ROOT/'reports/unittest.log').write_text(stream.getvalue())
    with tempfile.TemporaryDirectory() as temp:
        root=Path(temp); shutil.copytree(ROOT/'methods',root/'methods')
        p=complete(root); demo=p.validate(); demo['final_state']=p.status()['state']
    examples=[]
    for path in sorted((ROOT/'examples').glob('*.json')):
        output=run_analysis(read_json(path)); examples.append({'input':path.name,'kind':output['kind'],'input_sha256':output['input_sha256'],'status':'executed'})
    paired=subprocess.run([sys.executable,str(ROOT/'scripts/benchmark_controls.py')],cwd=ROOT,text=True,capture_output=True,timeout=120)
    original=read_json(ROOT/'reference/original_manifest.json')
    archive_match=file_hash(ROOT/'reference/ORIGINAL_ATLAS_UNMODIFIED.zip')==original['archive_sha256']
    audit=read_json(ROOT/'reports/original_audit_matrix.json')
    expected={x['path'].split('/',1)[1]:x['sha256'] for x in original['files']}
    actual={x['path']:x['sha256'] for x in audit}
    paired_data=read_json(ROOT/'reports/paired_controls.json') if paired.returncode==0 else {'results':[],'all_upgraded_expected':False}
    passed=structure['ok'] and result.wasSuccessful() and result.testsRun>0 and not result.skipped and demo['final_state']=='COMPLETE' and demo['evidence']['ok'] and paired.returncode==0 and archive_match and expected==actual
    report={'version':__version__,'started_at':started,'finished_at':now(),'seconds':time.perf_counter()-t0,
      'environment':{'python':sys.version,'platform':platform.platform(),'sqlite':sqlite3.sqlite_version,'copilot_runtime_executed':False,'network_calls_by_test_suite':0,'paid_api_calls':0},
      'structure':structure,'tests':{'run':result.testsRun,'passed':len([x for x in records if x['status']=='passed']),'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'cases':records},
      'synthetic_lifecycle':demo,'example_calculations':examples,'paired_controls':{'exit_code':paired.returncode,'stdout':paired.stdout,'stderr':paired.stderr,'cases':len(paired_data['results']),'all_expected':paired_data['all_upgraded_expected']},
      'original_audit':{'files':len(audit),'complete_hash_mapping':expected==actual,'untouched_archive_hash_matches':archive_match},
      'validated_inputs':{p.relative_to(ROOT).as_posix():file_hash(p) for p in ROOT.rglob('*') if p.is_file() and not set(p.relative_to(ROOT).parts)&{'reports','projects','__pycache__','.atlas','.git','history'} and p.name!='release_manifest.json'},
      'local_release_gate_passed':passed,
      'release_status':'QUALIFIED_LOCAL_RELEASE' if passed else 'BLOCKED',
      'unresolved':['Live Copilot compatibility and interaction behavior','Authenticated provider/MCP runtime tests','Independent post-implementation expert audit','Blinded equal-resource original-versus-upgraded research quality evaluation','Model-facing prompt-injection resistance','Other operating systems and Python versions'],
      'packaging':'Verified separately in reports/package_validation.json after archive extraction; not implied by this local gate'}
    atomic_json(ROOT/'reports/test_results.json',report)
    tests=result.testsRun; passed_count=report['tests']['passed']
    text=f'''# Actual testing and benchmark report

Release {__version__}. Final local run: {report['finished_at']}. **{passed_count}/{tests} tests passed**, {len(result.failures)} failures, {len(result.errors)} errors, {len(result.skipped)} skipped. Local release gate: **{report['release_status']}**. These are observed local test outcomes, not a research-accuracy score.

Evidence: [test_results.json](test_results.json), [full unittest log](unittest.log), [paired controls](paired_controls.json), [original baseline](baseline_results.json). Test environment: Python {platform.python_version()}, {platform.system()} {platform.machine()}, SQLite {sqlite3.sqlite_version}. Copilot executed: **no**. No model API, network request, or paid call was made by the test suite. Current external research was performed separately through the available browsing service.

## Executed layers and outcomes

| Layer | Actual execution | Result / boundary |
|---|---|---|
| 1. Structure | Required paths; shipped metadata subset; agent profile and skill frontmatter; Python AST; strict JSON; internal Markdown targets | {structure['checked_units']} checked units; {len(structure['errors'])} reported errors. Not a complete Copilot parser or semantic contradiction detector. |
| 2. Software | State/intake/task/cost/recovery, strict IO, source/claim review records, numerical provenance, method memory | {passed_count}/{tests} tests passed; see individual names/results. |
| 3. Copilot compatibility | Documentation comparison and static structure only | Live Copilot runtime not exercised; runtime compatibility unresolved. |
| 4. Interaction | Local init/stop, inquiry/answer persistence, mandate, assumptions and routing metadata | Local functions pass; actual conversation, relevance, conflict resolution and tool requests untested. |
| 5. Methods | Eight distinct domain profiles and synthetic plans reach RESEARCH; six calculator inputs execute | Correct local routing/artifact controls; appropriateness of real model-selected methods unmeasured. |
| 6. Adversarial/failure | Fake/reserved URLs, unmatched excerpts, duplicate IDs/origins, self-review, stale/future data, contradictions, changed calculations/units, absent APIs/fallbacks, path escapes, corrupt DB/checkpoint/ledgers | Expected local failures enforced. Malicious text is inert to Python; this is not a live LLM injection-resistance test. |
| 7. Comparative | {len(paired_data['results'])} paired selected checker cases using pristine original extraction and equivalent new defects | All new outcomes match declared expectations: {paired_data['all_upgraded_expected']}. No factual accuracy, cost or research superiority claim. |

## Local interaction coverage

| Required scenario | Evidence and limit |
|---|---|
| Fresh install/readiness/stop | Init prints exact sentence at end and creates no project; failure never prints ready. Real Copilot behavior not exercised. |
| Receive inquiry/start clarification | Project starts INTAKE, sequential gates block research; natural-language triggering remains unverified. |
| Thorough relevant interview/deliverables | Core/domain/adaptive question persistence and essential deliverables tested; relevance and phrasing require live review. |
| Partial user answers/end interview | Partial answers survive; essential gaps require explicit assumptions and acknowledgment. Actual user acknowledgment is operator recorded. |
| Conflicting requirements | Human/model procedure and held-out scenario supplied; no automatic contradiction solver. |
| Structured mandate/meta ordering | Saved mandate matches inquiry/answers; absent dossier/protocol blocks later work. |
| Missing tool access | Failed or limited-without-fallback readiness blocks; no automatic connection or billing. |
| Pause/cancel/resume | Persisted holds block CLI changes until explicit resume; external jobs are outside this mechanism. |

## Defects found and corrections

The first 68-test run passed 67 and exposed Decimal scientific notation in the break-even order count; formatting was corrected and the regression retained. A later 94-test run passed 92: two structural/init failures were missing report links while report assembly was incomplete. The completed reports resolved those failures; the final run above is authoritative.

Source/code review also found and corrected an edited-budget path that did not recheck mandate seals, task/cost ledger changes not covered by state receipts, post-reopen task-output integrity, missing explicit critical-review clearance, stale-source resolution, output-to-claim unit binding, and post-hoc evaluation criteria changes. These were engineering review findings, not claims of independently observed live Copilot failures. Regression tests exercise the corrected boundaries.

One deliberately retained limitation is tested: a real excerpt with an unrelated claim can still pass the mechanical validator if the supplied reviewer record falsely says it supports the claim. The result is labeled `mechanical_consistency_only` and warns about semantic limits. A model or qualified human must actually compare meaning. No passing local script qualifies a citation as substantively verified research.

## Paired control comparison

The comparison keeps the intended defect and local environment constant, adapting the schemas to each repository. The cases are selected adversarial checks, not a random sample and not a statistical estimate of real-world error rate. “Accepted” means the local checker returned success, not that a research system produced a correct conclusion.

| Injected case | Original accepted | Upgraded accepted | Expected interpretation |
|---|---:|---:|---|
'''
    for row in paired_data['results']:
        text+=f"| {row['case']} | {row['original_accepted']} | {row['upgraded_accepted']} | {row['interpretation']} |\n"
    text+='''
The original already rejects some defects; those are retained rather than advertised as novel. Both structural checkers accept sufficiently long meaningless policy prose, because syntax/file checks cannot establish methodological quality. The new system's substantive review requirement is an operating procedure and independent-review obligation, not a solved semantic detector.

## Formal release disposition

All original files have hash-linked audit rows. The six example calculators execute and the synthetic lifecycle reaches COMPLETE with evidence warnings explicitly identifying fixture data. The local release gate permits packaging only if all mandatory local checks pass. Package integrity/extraction is recorded separately after packaging; it is not inferred from unit tests.

The release is **qualified** because real Copilot runtime, authenticated provider tests, independent post-implementation audit, live adversarial model tests and blinded research-quality comparison remain unresolved. The earlier independent prototype auditor completed full-file reading/baseline checks; the parallel specialists subsequently stopped at an account usage limit. The primary author completed the implementation and final checks. This is not a completed independent audit of the upgraded code.

To reproduce: `python3 scripts/validate_release.py`. To exercise a synthetic workflow only: `python3 scripts/demo.py`. For real trials use [the evaluation protocol](../benchmarks/PROTOCOL.md) and [eight cases](../benchmarks/cases.json). The roadmap lists the remaining work.
'''
    (ROOT/'reports/TESTING.md').write_text(text)
    print(json.dumps({'release_status':report['release_status'],'tests':report['tests']['run'],'passed':report['tests']['passed'],'paired_cases':len(paired_data['results']),'original_files':len(audit)},indent=2))
    return 0 if passed else 1


records=[]
if __name__=='__main__': sys.exit(run())
