#!/usr/bin/env python3
"""Build a standalone ZIP and validate two independent extractions. No network."""
import argparse
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import tempfile
import zipfile
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from atlas.io import AtlasError, read_json, atomic_json, file_hash, now

ROOT=Path(__file__).resolve().parents[1]


def release_files(root):
    found=[]
    for p in sorted(root.rglob('*')):
        rel=p.relative_to(root); parts=set(rel.parts)
        if parts & {'__pycache__','.git','.atlas','.venv','dist','build','history'}: continue
        if p.name.endswith(('.pyc','.pyo')) or p.name.startswith('.env') or p.name in {'.mcp.json','settings.local.json'}: continue
        if rel.parts[0]=='projects' and rel.as_posix()!='projects/.gitkeep': continue
        if rel.parts[0]=='memory' and p.suffix=='.json': continue
        if p.is_symlink(): raise AtlasError('Release symlink forbidden: '+str(rel))
        if p.is_file(): found.append(p)
    return found


def write_manifest(root):
    rows=[{'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':file_hash(p)} for p in release_files(root) if p.name!='release_manifest.json']
    atomic_json(root/'release_manifest.json',{'schema_version':1,'hash_algorithm':'SHA-256','scope':'All packaged files except this self-referential manifest','files':rows})
    return rows


def make_zip(root,dest):
    with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in release_files(root):
            info=zipfile.ZipInfo('ATLAS/'+p.relative_to(root).as_posix(),date_time=(2026,11,3,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED; info.external_attr=0o100644<<16
            z.writestr(info,p.read_bytes())


def verify_zip(archive,dest):
    with zipfile.ZipFile(archive) as z:
        bad=z.testzip()
        if bad: raise AtlasError('Corrupt ZIP member '+bad)
        for item in z.infolist():
            p=PurePosixPath(item.filename)
            if p.is_absolute() or '..' in p.parts or '\\' in item.filename or ':' in item.filename or not item.filename.startswith('ATLAS/'):
                raise AtlasError('Unsafe archive member')
        if len(z.namelist())!=len(set(z.namelist())): raise AtlasError('Duplicate archive names')
        z.extractall(dest)
    root=dest/'ATLAS'; manifest=read_json(root/'release_manifest.json')
    expected={x['path']:(x['bytes'],x['sha256']) for x in manifest['files']}
    actual={p.relative_to(root).as_posix():(p.stat().st_size,file_hash(p)) for p in release_files(root) if p.name!='release_manifest.json'}
    if expected!=actual: raise AtlasError('Release manifest mismatch')
    original=read_json(root/'reference/original_manifest.json')
    if file_hash(root/'reference/ORIGINAL_ATLAS_UNMODIFIED.zip')!=original['archive_sha256']: raise AtlasError('Original archive not preserved')
    commands=[]
    for cmd in [[sys.executable,'-m','atlas','check'],[sys.executable,'-m','unittest','discover','-s','tests','-v'],[sys.executable,'scripts/demo.py']]:
        result=subprocess.run(cmd,cwd=root,text=True,capture_output=True,timeout=120)
        commands.append({'command':cmd[1:],'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
        if result.returncode: raise AtlasError('Extracted release check failed: '+repr(commands[-1]))
    return {'files':len(actual)+1,'manifest_matches':True,'original_archive_preserved':True,'commands':commands}


def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--output',type=Path,default=ROOT.parent/'ATLAS_Research_OS_v3.0.0_Copilot.zip'); args=parser.parse_args()
    report=read_json(ROOT/'reports/test_results.json')
    if not report.get('local_release_gate_passed'): raise AtlasError('Run and pass validate_release.py first')
    for rel,h in report.get('validated_inputs',{}).items():
        if file_hash(ROOT/rel)!=h: raise AtlasError('Input changed after validation: '+rel)
    if not report.get('validated_inputs'): raise AtlasError('Validation lacks input hashes; rerun current validation')
    with tempfile.TemporaryDirectory() as temp:
        tmp=Path(temp); stage=tmp/'stage'; stage.mkdir()
        for p in release_files(ROOT):
            if p.name=='release_manifest.json' or p.relative_to(ROOT).as_posix()=='reports/package_validation.json': continue
            dest=stage/p.relative_to(ROOT); dest.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(p,dest)
        write_manifest(stage); candidate=tmp/'candidate.zip'; make_zip(stage,candidate)
        candidate_result=verify_zip(candidate,tmp/'candidate-extract')
        receipt={'validated_at':now(),'phase':'Candidate archive extracted and tested before adding this receipt; final archive is independently extracted again by packaging script',
          'candidate_validation':candidate_result,'final_archive_hash_location':'Companion research and engineering report',
          'limitations':['No live Copilot or optional API execution','Integrity hashes are not digital signatures']}
        atomic_json(stage/'reports/package_validation.json',receipt); atomic_json(ROOT/'reports/package_validation.json',receipt)
        write_manifest(stage); args.output.parent.mkdir(parents=True,exist_ok=True); make_zip(stage,args.output)
        final_result=verify_zip(args.output,tmp/'final-extract')
        shutil.copy2(stage/'release_manifest.json',ROOT/'release_manifest.json')
        final_receipt={'at':now(),'archive':str(args.output.resolve()),'sha256':file_hash(args.output),'bytes':args.output.stat().st_size,'final_extraction':final_result}
        atomic_json(ROOT.parent/'final_package_receipt.json',final_receipt)
        print(__import__('json').dumps({'archive':str(args.output),'sha256':final_receipt['sha256'],'bytes':final_receipt['bytes'],'files':final_result['files'],'independent_extractions':2,'checks_passed':True},indent=2))


if __name__=='__main__': main()
