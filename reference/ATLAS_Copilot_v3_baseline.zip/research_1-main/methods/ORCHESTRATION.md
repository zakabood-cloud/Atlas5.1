# Orchestration, context and model routing

The default is one coordinator and the minimum necessary specialists. Parallelize independent source families, geographic comparisons, competing hypotheses or verification; keep sequential inferential chains together. A worker receives the neutral mandate, only needed protocol sections, a bounded objective, evidence requirements, explicit tool permissions and a unique branch output. The coordinator owns shared registries and lifecycle mutations. Never let multiple agents rewrite the same ledger simultaneously.

A challenger should form an initial account without seeing the preferred conclusion where feasible. Same-model isolated review is useful but is not independent-model validation. Different model brands may use the same sources and share biases. Count independent originating evidence, not agreeing agents. Inspect disagreements and underlying assumptions rather than voting on conclusions. Role count is a budget/design choice, not a score.

Use `model: inherit` by default so account availability is respected. When choosing a model explicitly, verify the current available ID and record it; compare representative tasks at equal access and bounded budgets. Route simple extraction to a cheaper model only after measuring unacceptable errors and checking source output. Reserve stronger reasoning for ambiguous design, inference and adversarial review. No current model is declared universally best. External research engines are optional independent evidence-discovery routes, subject to access/privacy/spend permission; their reports still require source audit.

Current controlled agent research reports task-dependent gains and losses from coordination, while vendor engineering reports show benefits in their own research deployment. Neither establishes an optimal ATLAS agent count. This release chooses a central ledger and bounded task DAG as an engineering default. [Scaling agent systems v3](https://arxiv.org/abs/2512.08296v3); [Anthropic engineering](https://www.anthropic.com/engineering/multi-agent-research-system).

At handoff, persist source IDs, excerpts, dates, origin groups, calculations and unresolved questions. Return paths plus a concise interpretation rather than re-summarizing everything through multiple layers. Recheck claim-to-source mapping during final synthesis; published work identifies citation loss during agent handoffs. [Faithfulness localization](https://aclanthology.org/2026.emnlp-main.1681/).

The Python DAG is a record and gating system, not a background service. Agent teams are optional experimental Claude functionality and are not enabled. Background completion, provider cancellations, live task scheduling and multi-process lease management are outside this release. On interrupted work, inspect recorded status; explicitly fail/reset a running task after checking whether its output exists. Do not resubmit costly work blindly.

## v3 executor and explicit task exceptions

Prefer a single coordinator mutating Project state. The Python scheduler operates on existing RESEARCH task DAGs and launches tasks using a provided worker. It does not select methods or independently verify the returned evidence. An opt-in Claude CLI subprocess is an experimental route; test actual login, data access and billing before production. Never run the synthetic fixture worker as evidence for an actual user question.

A noncritical task may be marked `blocked` or `skipped` only with an explicit recorded decision-impact reason. Critical or unresolved tasks must be completed or the protocol reopened/amended. Do not mark a failed external request as `done` to satisfy a gate.

Independence requires separated source search plans, first-pass findings isolated from the leading thesis, and source-origin tracing. Do not use agent voting as a proxy for empirical evidence.
