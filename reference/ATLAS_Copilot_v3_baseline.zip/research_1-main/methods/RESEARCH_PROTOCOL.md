# Domain-specific research preparation and execution

## Meta-research as a bounded design experiment

Before topic conclusions, formalize the question and investigate how a capable professional would answer it. Compare at least a simple structured approach and a stronger design. For each, identify what can actually be measured, which biases it introduces, the needed expertise/data, cost, access and a decisive feasibility test. Search current professional standards and methodological literature, not just vendor marketing. Inspect a representative source and extraction path; document failed access honestly.

Deliver a dossier plus protocol: question; alternatives; definitions; inclusion/exclusion; expected outcomes; source families; exact query plan; measurements; coverage dimensions; analytical methods; verification coverage; resources; stopping rule; expert-review needs; amendment policy. Preserve retrieval dates and versioned source metadata. A more elaborate method that cannot obtain its inputs is weaker than an executable narrower design.

Preparation defaults to one pass, with up to two targeted repair passes for material failures. This is an engineering default to bound recursion, not a scientifically proven optimum. Do not meta-research how to meta-research indefinitely. If the question is unidentifiable with accessible evidence, state that and select a useful restricted design or stay blocked. Pilot observations can later enter the main study only when the protocol explicitly includes them; they are not confirmatory results by default.

## Search, coverage and stopping

Build a matrix of decision dimensions × competing hypotheses × source families, with geography, dates, language and negative-evidence queries where relevant. Track exact search strings, tool/index, filters, dates, result-handling rules, attempted pagination and reasons for exclusion. Follow original-source chains and distinguish records from underlying studies/events. Failure to access a source is missing evidence, not zero demand or absence of an effect.

Stop when protocol-defined consequential dimensions have adequate support or explicit gaps, major counterclaims have been sought, and the next feasible query is unlikely to alter the decision at an acceptable cost. For each remaining uncertainty record its plausible range, potential decision reversal, accessible measurement and cost. EVPI can bound the value of perfect information under declared utilities/probabilities; it does not calculate the value of an actual search. A gap that could reverse the answer requires a conditional conclusion or proposed experiment, not artificial certainty. Clinical systematic reviews follow their protocol-defined search obligations rather than a casual web saturation rule. [Cochrane search](https://www.cochrane.org/authors/handbooks-and-manuals/handbook/current/chapter-04); [PRISMA-S](https://www.prisma-statement.org/prisma-search).

## Transferable versus domain-specific methods

All domains need explicit questions, evidence provenance, consistent definitions, contrary evidence, reproducible calculations, uncertainty and decision-relevant stopping. They do not share one universal source hierarchy or scoring formula.

| Domain | Appropriate design and safeguards |
|---|---|
| Amazon products | Marketplace-specific demand/competition sampling, seasonality and stockout checks, actual supplier quotes, current fee/tax/compliance assumptions, contribution and cash cycle; estimated competitor sales remain estimates. |
| Shopify vs Amazon | Match product, date, return and fulfillment basis; distinguish incremental acquisition from attribution; evaluate owned cohorts and realistic operating capacity. |
| UAE vs US markets | Align population/product/channel denominators, reference periods, currencies and market-access constraints; national totals do not measure a niche entrant's attainable sales. |
| Opportunity discovery | Include doing nothing and opportunity cost; reference classes, falsifiable customer hypotheses, distribution advantages, early low-cost tests; no made-up success probabilities. |
| Finance | Original filings and notes, cashflow/liquidity stress, valuation scenarios, governance and downside; align fiscal periods, avoid survivorship and look-ahead bias. |
| Science | PICO/PECO, protocol, reproducible database search, duplicate study linkage, screening/exclusions, risk of bias, compatible outcomes and certainty judgments. No automated meta-analysis is supplied. |
| Technology | Requirements and representative workload benchmark, versions, tool limits, latency/error rates, cost and failure recovery; compare the complete system and underlying model separately. |
| General investigation | Operational definitions, chronology, primary-document tracing, alternative explanations, source dependency and appropriately limited conclusions. |

PRISMA is reporting guidance, not a certificate of conduct or certainty; Cochrane addresses review methods; GRADE assesses certainty for outcomes within its appropriate context. They should not be pasted into a commercial opportunity ranking as numerical quality scores. [PRISMA 2020](https://doi.org/10.1136/bmj.n71); [GRADE criteria](https://www.cdc.gov/acip-grade-handbook/hcp/chapter-7-grade-criteria-determining-certainty-of-evidence/index.html).

Causal claims require an identification strategy and explicit assumptions, not merely correlation or a before/after comparison. Forecasting needs honest out-of-time evaluation, baselines and interval assessment; simulations conditional on invented distributions cannot supply calibration. For specialist models use validated packages and expert review. [Hernán and Robins](https://miguelhernan.org/whatifbook); [Forecasting toolbox](https://otexts.com/fpp3/toolbox.html).

## v3 retrieval and method-selection responsibilities

- The META stage must use domain-specific professional methodology research, compare a simple design against more complex methods, and record a pilot. `atlas.methodology.score_methods` evaluates declared observed pilot scores but cannot select the optimal method objectively without reliable test data.
- Adapt retrieval through query expansion, independent primary-source discovery, negative evidence, study/market scope, and original-source lineage. Use `atlas.retrieval.coverage_audit` for structural gaps; do not claim high recall without an independent gold standard.
- Crossref/OpenAlex adapters expose bibliographic metadata only. Do not quote retrieved abstracts as full papers or treat metadata as primary evidence of market outcomes.
- Do not automatically share previous winning conclusions with an independent challenger. Use data-derived scenarios, reference classes and validated causal methods where available.
- Final report must declare confidence and decision reversal conditions, and label blocked critical evidence or inaccessible specialist databases.
