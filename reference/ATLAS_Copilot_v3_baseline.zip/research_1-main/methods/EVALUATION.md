# ATLAS 3 — Independent benchmarking and quality gates

Separate evaluation layers: software unit tests; live Claude Code execution; retrieved-source accuracy; semantic citation audit; blinded domain expert judgment; decision calibration using later observations.

For the same matched resources and research mandate, compare: baseline simple researcher, ATLAS 2, ATLAS 3 without optional components, ATLAS 3 with each optional component. Randomize order and blind assessors where feasible. Preserve exact versions, source access dates, original answer keys and costs. Keep holdout sets separate from method development. Do not proclaim universality from small samples. Calculate error by severity and abstention rate, not just total report score. Evaluate negative evidence, source dependency and reversal conditions. A local fixture or scripted demo is *not* a live research benchmark.

When external APIs are unavailable, label the result as offline. Record unverified capabilities and a concrete live validation plan.
