---
name: research-deliver
description: Create exactly the ATLAS user-selected research deliverables, verified report, reproducible datasets/models, source audit, ranked recommendations and transparent uncertainty statements.
---
# Research deliverables and user experience

**Entry:** `AUDIT` passed, conditionally passed or documented transparent partial work. Read `01_intake/deliverables_contract.md` as the source of truth for output formats. Do not quietly substitute another format for a requested one.

## Final answer order
1. Direct answer / decision recommendation and level of confidence.
2. Precisely what was studied; geography, period, definitions, methodology and scope.
3. Ranked alternatives and decisive evidence, with anchored citations.
4. Financial/economic/scientific results as applicable; uncertainty, down-case and rank sensitivity.
5. Strongest contrary case and critical unknowns.
6. Next best real-world tests or due-diligence actions with thresholds; do not claim executed tests unless executed.
7. Methodology, source register, replicable calculations and version/audit appendices.
8. Actual files in requested formats with transparent missing items.

## Deliverable types
- **Executive memo:** clear action, reasons, risk, missing facts, decision conditions.
- **Comprehensive research report:** objectives, design, sources, search strategy, findings, evidence tables, competing hypotheses, calculations, limitations, conclusion.
- **Ranked decision matrix:** individual factor inputs, sources, rationale, objective/subjective weights and sensitivity to weights.
- **Editable financial workbook / calculations:** source-linked inputs, formulas, assumptions, scenarios, currency/tax and dates, validation tests.
- **Source register:** origin, precise link/DOI, access data, publication/data date, limitations and claim references.
- **Audit pack:** contradictions, unresolved claims, verification status, reproducibility log and methodological amendments.
- **Research playbook:** steps, tools, prerequisites, gates, operators and risks.
- **Implementation experiment plan:** only if asked, define hypothesis, measurement, sample, costs, ethics, success/failure thresholds.
- **Raw and processed data:** according to licensing/privacy rights; state any restrictions.
- **Presentation / PDF / DOCX / XLSX:** generate using environment-available tools; verify file exists and opens, do not merely rename a Markdown file to another extension.

## Report quality standards
Use precise currency/time units, adequate charts, legible tables, citations close to facts, no unsupported superlatives, no wordy filler. Explain methodology in enough detail for independent replication. Include a one-page summary and detailed appendix when comprehensive length requested.

## If format tools unavailable
Do not fabricate downloadable links. Provide a polished Markdown/CSV fallback with explicit description of unmet format and why. Generate actual requested formats whenever possible using installed toolchain. Do not embed sensitive raw inputs in a public artifact.

## File manifest and QA
Write `05_deliverables/deliverable_manifest.md` listing user request, created path, size, format, version and validation outcome. Every file needs meaningful content, no placeholders. Have the auditor check that report facts and data correspond to the audited ledgers.

## Accuracy disclosures
Prominently state data retrieval date, important primary/secondary source limits, paid datasets unavailable, stale metrics, modeled assumptions, exact audit scope and unresolved issues. Never say "all available sources" unless precisely defined and verified.
