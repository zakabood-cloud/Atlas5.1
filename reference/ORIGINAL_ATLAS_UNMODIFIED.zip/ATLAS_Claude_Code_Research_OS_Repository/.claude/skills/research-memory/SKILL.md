---
name: research-memory
description: Convert validated research process lessons into reusable, versioned ATLAS method memory while separating transient facts, private client data and unverified advice.
---
# Evidence-aware research methods memory

Read `research_os/methods/MEMORY_POLICY.md` and `research_os/evaluations/EVALUATION_PROTOCOL.md`. Memory should make the **next research method better**, not make outdated market facts look permanent.

### End-of-project reflective record
Write `06_learning/postmortem.md`: what method worked, which data source failed, tool pilots, unexpectedly useful search terms, contradictory sources, audit findings, numerical errors caught, actual cost if measurable, quality-gate failures and proposed improvements.

### Proposed memory item
For each candidate reusable item include: `method_id`, topic/domain, original question, methodological lesson, source/protocol used, empirical result or evaluation outcome, accuracy limits, required tool/data access, date, freshness/expiry/review trigger, confidentiality class, suggested reuse, counterexamples. Distinguish observed improvement from theory.

### Promotion process
1. Exclude personal identifiers, private inputs, secrets, vendor quotes or private data without explicit permission.
2. Ensure evidence/provenance and an operationally clear applicability condition.
3. Compare new recommendation to existing memory for contradiction or duplication.
4. Run a small regression or held-out test where available; proposals without tests remain `CANDIDATE` not `VALIDATED`.
5. Update `research_os/methods/METHODS_INDEX.md` and the relevant domain method only when justified; preserve history and rollback path in Git.
6. Tag tool/model capabilities for revalidation, not perpetual truth. Product pricing, API compatibility, and regulations require fresh checks every use.
7. If project includes sensitive or proprietary data, store only de-identified general procedural insights with permission or keep memory project-local.

### Retrieval for next inquiry
At Phase 0 query methods index by domain, measurement, geography, data type and tool capabilities; collect relevant past lessons. Verify they apply to the new case and recheck source/tool currency. Never replace new research with memorized conclusions.

### No automatic authority escalation
The agent may propose process updates, but may not silently remove the intake interview, disable evidence gates, loosen permissions, or weaken audit criteria. Major instruction changes require a reviewed version and successful benchmark comparison, with user approval where appropriate.
