---
name: research-audit
description: Independently audit ATLAS investigation before delivering findings; verify critical claims, sources, calculations, counterevidence, data provenance, decision robustness and completeness.
---
# The final evidence and decision audit

**Entry:** after research has produced a provisional conclusion and source/claim ledgers. Read the constitution, claim standards, numerical standards and quality gates. Independent auditor must not simply endorse the director's prose.

### A1. Coverage audit
Compare original question and signed intake requirements with the coverage tree, search log and candidate funnel. Flag omitted countries, categories, stakeholder groups, time periods, alternatives, contradictory hypotheses or key drivers. Test whether the final winner benefited from unequal depth of research.

### A2. Citation-by-claim audit
Decompose final decision-critical assertions into atomic claims. For each, open supporting source and inspect precise passage, page/table, data period, geography, units, sampling and limitations. Check whether the stated claim is narrower/equal to evidence; challenge all unjustified generalizations. Reconstruct source independence graph and detect circular citations, press release duplication, abstracts masquerading as full texts and dead URLs. Record `V0/V1/V2/V3/X` result for each critical claim.

### A3. Quantitative audit
Re-run scripts and datasets; compare outputs to report numbers. Confirm source inputs, correct units, exchange rates, dates, taxes, profit-versus-revenue definitions, accounting for CAC and returns, cash-flow logic, sample sizes, uncertainty and rounding. Stress test core parameters and validate ranking stability. Cross-check representative calculations independently.

### A4. Adversarial audit
Construct the strongest opposing thesis, preferably from independent primary evidence and different analytical assumptions. Identify where source selection, optimistic financial inputs, survivor bias, regulation, missing customer observations or competition could invalidate the recommendation. Compare alternate winners under reasonable objective weights.

### A5. Temporal and domain audit
Check that current laws, fees, competitor status, product details, model versions and commercial benchmarks reflect the relevant time period. Flag stale/noncomparable evidence and provider estimates presented as fact. Recommend professional review where appropriate.

### A6. Security and scope audit
Confirm no unapproved purchases, secret leakage, external data uploads, unauthorized API use, tool misrepresentation or promises of background work. Confirm deliverables reflect the user's choices rather than an imposed template.

### A7. Record issues and attempt corrections
Write `04_audit/claim_audit.csv`, `04_audit/coverage_audit.md`, `04_audit/model_audit.md`, `04_audit/adversarial_review.md`, `04_audit/security_scope_audit.md`, `04_audit/corrections_log.md`, `04_audit/quality_gate_decision.md`. Fix the source, formula or claim; do not merely change a score to pass. Cite remaining issues in user report.

### Gate decision
- **PASS:** all decision-critical claims V2+ (or explicitly conditional/unsupported), models reproducible, major contradictions handled, omissions disclosed and decision sensitivity analyzed.
- **CONDITIONAL PASS:** important but nonfatal gaps, communicated prominently with limits; no false certainty.
- **FAIL/PARTIAL:** critical unresolved inaccuracies or unvalidated economics. Return to specified research task or deliver transparent partial work without confident winner.

When `audit_project.py` is available, run it and inspect output. Script compliance is a floor; logical truth is an additional human/model audit. The verifier is not a substitute for actual source inspection.
