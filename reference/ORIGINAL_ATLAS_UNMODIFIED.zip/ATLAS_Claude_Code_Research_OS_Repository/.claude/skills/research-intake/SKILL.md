---
name: research-intake
description: Mandatory first step after a new ATLAS research inquiry. Interview the user extensively and determine precise objectives, constraints, evidence requirements, budget and desired deliverables before ANY topic research.
---
# Research intake — USER INTERVIEW FIRST

**Non-negotiable:** This skill executes after a **separate user inquiry** following initialization. Before intake completion, do NOT conduct topic research or meta-research; do not search the web, launch research agents, consult market databases, or identify specific answers. Questions may be reasoned from the user's wording and `research_os/intake/QUESTION_BANK.md`. **More relevant clarification is better than fewer questions; irrelevant interrogation is not.**

1. Create `research_os/projects/<YYYYMMDD-short-slug>/` and `state.json` with `INTAKE`. Record the question verbatim in `01_intake/original_question.md`. Do not include identifiers or sensitive data in the slug.
2. Open `research_os/intake/QUESTION_BANK.md`. Construct a **topic-specific, exhaustive interview map**. Explore explicit and hidden dimensions; do not assume that a user's words mean only one thing. Distinguish essential decision-defining questions from optimization preferences.
3. Ask in coherent themed batches, normally 12–25 substantial questions per batch for broad research, as many as necessary for complex inquiries. Number questions, offer explicit options where useful, and allow long-form replies. Default to **2–4 adaptive rounds**, extending for significant unanswered branches, not arbitrary maximum counts. Let the user answer in one message or skip questions; do not burden them with questions already answered.
4. In the **first batch**, ALWAYS explicitly ask about required deliverables and desired output format, level of detail, structure, language, and source/audit appendices. Also ask what success means, scope, timeframe, geography, comparison set, tradeoffs, and whether preferences should influence ranking.
5. In subsequent batches, ask only the most decision-sensitive unresolved questions and domain-specific details. Surface hard-to-anticipate dimensions: regulatory scope, thresholds, unit economics, access permissions, confidential files, risk tolerance, real-world validation, whether user wants broad discovery or specific choices. Offer "not sure", "not applicable" and "research this objectively" options.
6. Present a concise **interpretation check** after each major round, labeled `confirmed / unknown / working assumption / explicitly excluded`. Ask for correction of ambiguities. Ask about available datasets and tools but do not connect or use them yet.
7. Distinguish (a) objective evidence criteria from (b) normative user preferences. When asked to be general, do NOT infer restrictions from the user's circumstances. For ambiguous rankings, expose the different objectives and request a primary ordering or multi-objective analysis.
8. The user may say **"use your judgment", "skip questions", or "no more questions"**. Respect this, set transparent assumptions, and do not block research unnecessarily. However, **never infer approval to purchase, send information, create accounts, scrape restricted sites or perform external actions**.
9. On completion, save `01_intake/confirmed_brief.md`, `01_intake/answers.md`, `01_intake/assumptions.md`, `01_intake/deliverables_contract.md` and `01_intake/open_issues.md`. The deliverables contract MUST exist even if user delegates format selection.
10. State the complete interpreted mandate, define decision objective(s), comparators, exclusions, geography, horizon, definitions, available data/tools, deliverables, budgets and permission boundaries. Set stage `INTAKE_COMPLETE`, then enter meta-research; user confirmation is only required if a material ambiguity remains or user requested approval. **Do not secretly begin main research while asking questions.**

### First-batch template (adapt, expand, do not mindlessly paste every item)
- What exact decision is this research meant to support? What would count as success or failure?
- Should the analysis be general/unrestricted, or tailored to any specified personal/company conditions? Which constraints must be excluded?
- What are the market(s), location(s), audience, dates, horizon, and comparison options?
- Which objective dominates: absolute profit, ROI, risk-adjusted return, scalability, speed, defensibility, valuation, or another outcome?
- What evidence threshold is required, and how should uncertainty be presented?
- How wide should we search for alternatives before selecting finalists?
- What costs, access permissions, specific datasets, prior studies or examples are available?
- Do you want real-world empirical testing proposed, or actual low-risk tests run after approval?
- **Exactly what deliverables do you want?** Executive report, full detailed report, PDF, Markdown, DOCX, spreadsheet/models, charts, databases/CSV, source links, reproducible code, slide deck, ranked opportunities, scripts, raw data, audit trail, presentation, implementation plan, or other?
- Who will use the deliverables, what language, expected length, level of technical rigor and preferred citation format?

### Interview completion test
The interview ends when the question has clear decision target; core boundaries; evaluation criteria; output contract; permission/cost policy; material unknowns are either answered or explicitly assumed. A long list of low-impact unanswered preferences is **not** a reason to prolong questioning against the user's wishes.
