---
name: research-meta
description: Mandatory post-interview, pre-research stage. Investigate how the question should best be researched; discover and pilot methods, specialist sources, tools and MCP servers; produce a frozen, audited research protocol.
---
# PHASE 0: Meta-research — research how to research first

Do not enter until `INTAKE_COMPLETE`. Read `research_os/policies/RESEARCH_CONSTITUTION.md`, `research_os/policies/TOOL_AND_SOURCE_INTELLIGENCE.md`, `research_os/policies/SECURITY_AND_PERMISSIONS.md` and the domain playbook that applies. Inspect curated method memory **as leads only**, never an assumption of current correctness.

### 0.1 Formalize the research problem
- Translate the user's question into an answerable problem: decision unit, operational definitions, observable outcomes, comparator set, geography, timeframe, causal vs predictive vs descriptive claims, evidence required and explicit user value weights.
- Build a **coverage ontology** including conventional and overlooked approaches, alternative hypotheses, stakeholder views, negative outcomes and likely missing data.
- Determine if the problem is structurally identifiable from accessible data. If not, specify what empirical tests or assumptions are required.

### 0.2 Investigate the methodology itself
Search up-to-date methodological literature, primary standards, professional approaches, vendor methods and relevant prior research. Compare at least two credible methodological approaches when stakes merit it. Consider statistical validity, sampling, selection bias, survivorship, measurement error, generalizability, reproducibility, cost and decisions enabled. Do not conflate a popular checklist with proof of optimality.

### 0.3 Source intelligence
- Create a source landscape: primary authorities, official platforms, registries, original studies, first-party user data, industry subscription databases, observation sources and contrary evidence.
- For each source describe: variable measured, unit/population, geography, sampling frame, frequency, latency, access route, license, costs, failure modes, known uncertainty, and whether data is actual or modeled.
- Build inclusion/exclusion rules and planned search expressions. Consider alternate languages and search avenues as needed.

### 0.4 Tool and MCP intelligence
- Inventory tools genuinely accessible in this Claude environment. Test names/status without disclosing credentials. Discover other candidates via **official documentation** and reputable MCP registries, plus domain-specific data vendors.
- A named vendor is a **candidate**, not an available connector. Verify actual endpoint, coverage, version, permissions, terms, license and ability to retrieve a representative response.
- Pilot the highest-value already-authorized tools on **small scoped tasks**. Record response validity, error rate, data freshness, quota impact and compatibility. Request consent before installing code, configuring unfamiliar MCP servers, purchasing data, sending sensitive content or incurring external charges beyond established permissions.
- Record four statuses: `READY_TESTED`, `CONFIGURED_UNTESTED`, `ACCESS_REQUIRED`, `REJECTED`. Do not claim usable capabilities under other statuses.
- Rank by incremental decision value, not brand recognition: expected uncertainty reduction versus cost, privacy risk, access reliability and source independence.

### 0.5 Research organization and proof strategy
- Architect independent topical subinvestigations and agent responsibilities. Allocate roles only when outputs are separable; use fresh context for rival hypotheses. Define expected outputs and source-ledger format before spawning.
- Choose concrete statistical/data analysis methods and validity tests. Plan counterexample search, sensitivity analysis and independent source verification.
- Define the question-specific quality rubric and stopping/expansion criteria, traceable to how a missing fact could change the user's decision.

### 0.6 Small feasibility pilots
Run representative permitted samples to check source validity, data extraction, schemas, cost assumptions and methodology. Correct tool choice when pilots fail. Do not confuse these small tests with substantive final evidence.

### 0.7 Methodology adversarial challenge
Ask an independent methodology reviewer: "How can this protocol fail despite apparently abundant research? Which biased/omitted data would reverse the result? Is it using appropriate measurements? Are citations auditable? Are comparisons like-for-like?" Resolve issues or register limitations.

### 0.8 Preparation dossier and freeze
Write to `02_meta_research/`:
`question_formalization.md`, `coverage_tree.md`, `method_candidates.md`, `methodology_selection.md`, `source_landscape.csv`, `tools_registry.csv`, `pilot_tests.md`, `access_requests.md`, `agent_plan.md`, `measurement_plan.md`, `verification_plan.md`, `methodology_red_team.md`, `research_protocol_v1.md`, `readiness_gate.md`.

**Readiness gate:** There is a defensible method, coverage matrix, tool/source plan, independent reviewer, valid measurement definitions, reproducible quantitative strategy if needed, clear blockers/fallbacks, and specific deliverables. No purchase or missing external credential may be silently treated as resolved. `META_READY` means ready to proceed at the **stated capability level**, not omniscience. After status is frozen, move to substantive research.

### Reopen conditions
During research, amend the protocol only when unexpected evidence reveals meaningful measurement bias, missing authoritative data, a severe coverage gap or a better executable method. Version all amendments and note their possible effect on conclusions. Never recursively research research methodologies without an expected decision benefit.
