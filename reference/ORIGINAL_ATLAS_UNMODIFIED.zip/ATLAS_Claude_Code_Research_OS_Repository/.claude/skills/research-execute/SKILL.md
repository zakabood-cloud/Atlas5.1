---
name: research-execute
description: Execute the frozen topic-specific ATLAS research protocol after intensive intake and Phase 0 preparation; preserve original evidence, task coverage, calculations, independent interpretations and contradictions.
---
# Substantive investigation and quantitative execution

**Entry:** only after `META_READY` and a documented research protocol. Read `research_os/policies/ORCHESTRATION_AND_SEARCH.md`, `research_os/policies/CLAIM_AND_DATA_STANDARDS.md`, `research_os/policies/DECISION_AND_STATISTICS.md` and applicable domain playbooks.

### E1. Initialize investigation
Create `03_research/` subfolders `branches/`, `raw_evidence/`, `processed_data/`, `search_logs/`, `calculations/`, `contradictions/`, `experiments/`. Initialize ledgers from `research_os/templates/PROJECT_SCHEMAS.md`; record runtime versions and frozen methods. Build task dependency graph and independent branch briefs.

### E2. High-recall discovery
Run broad concept coverage across planned primary/secondary sources and relevant languages. Log search expressions, dates, result counts when meaningful, inclusion/exclusion, extracted data and source identifiers. Expand into neglected sectors/options when evidence warrants it. Use controlled candidate screening, not cherry-picked favorite examples.

### E3. Deep evidence acquisition
Retrieve original documents and actual datasets for decision-critical findings; store stable reference, extraction offsets/sections/tables, measurement definitions, locale, effective date, methodology and access conditions. Do not treat rankings, snippets, vendor marketing or AI summaries as raw demand measurements. Track possible common source origin.

### E4. Triangulate and disconfirm
Use at least two *independent evidence families* where feasible for pivotal externally reported facts. Search direct contradiction and negative-case evidence before identifying winners. Investigate competing explanations: seasonality, distribution advantage, selection/survivorship bias, reporting bias, regional product differences, pricing and currency changes, sample effects.

### E5. Quantification and validation
Use actual scripts or traceable spreadsheet formulas for calculations. Clearly separate known source inputs and assumed inputs. Check double counting, revenue-versus-profit, channel attribution, inflation, taxes, acquisition spend, capital costs, missingness, units, outliers, sample biases and numerical precision. Build sensitivity/range scenarios and test decision rank reversal. No made-up exact market share or conversion values.

### E6. Independent review while executing
Assign counterevidence search before final synthesis. Require each branch to hand back findings, supporting source IDs, missing variables, uncertainty, contradictory evidence and reproducible calculation paths. Verify that no source count is inflated by syndication.

### E7. Research saturation decision
For each decision-critical unknown evaluate (impact of uncertainty) × (feasibility of acquiring evidence). Expand work when a new search is likely to reverse ranking or materially narrow uncertainty. Stop when coverage gate, source audit readiness and realistic resources permit, or declare explicit incompleteness. Record unexamined avenues.

### E8. Handoff
Write `03_research/research_log.md`, `03_research/coverage_matrix.csv`, `03_research/source_registry.csv`, `03_research/claim_ledger.csv`, `03_research/assumptions.csv`, `03_research/contradiction_register.csv`, `03_research/analysis_manifest.md`, `03_research/provisional_findings.md`. Set stage `AUDIT` only when files exist or a justified not-applicable marker is present. **Provisional findings are never final facts.**
