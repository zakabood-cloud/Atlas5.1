# ATLAS — Claude Code Research Operating System

**Deployment:** This is the **pre-installed multi-file version** of the ATLAS Research OS. It requires no extraction of instructions from the master Markdown. Claude Code discovers the project instructions from `CLAUDE.md`, specialist agents from `.claude/agents/`, and skills from `.claude/skills/`.

## Getting started

1. Unzip the complete archive into a new folder/repository. **Preserve hidden `.claude` files and folders.**
2. Open that folder as your working directory in Claude Code (CLI, desktop, or repository-aware session). Do not open a parent folder or just the Markdown file.
3. Send the following first message to Claude Code:

> Initialize this pre-installed ATLAS Research OS repository. Read CLAUDE.md and research_os/operations/STATE_MACHINE.md, run `python3 research_os/engine/verify_install.py`, perform a local-only inventory of tools and configured MCP connectors without revealing secrets, create the necessary initial state and capability record, then send the prescribed readiness message and STOP. Do not begin any research or ask intake questions yet.

4. Wait until Claude states: **ATLAS Research OS is initialized and ready for your research inquiry.** It should provide a factual capability status and disclose any unavailable tools.
5. Send your research inquiry. Claude **first conducts an extensive clarification interview**, including desired deliverable formats, before any topical or meta-research.
6. Once intake is complete, it investigates **how to research that specific question**: best methodology, sources, data access, tools, agent roles and verification. It then conducts, audits, reports and records lessons from the actual research.

## Architecture

| Path | Purpose |
|---|---|
| `CLAUDE.md` | Short persistent project instructions and lifecycle gates |
| `.claude/agents/` | 8 specialist subagent definitions |
| `.claude/skills/` | 6 on-demand stage skills |
| `research_os/policies/` | Research rigor, claim verification, safety and methodology |
| `research_os/intake/` | Extensive adaptive question bank |
| `research_os/domains/` | Domain-specific research playbooks |
| `research_os/engine/` | Local verification and structural audit scripts |
| `research_os/methods/` | Curated, versioned cross-project methods memory |
| `research_os/projects/` | Private per-inquiry research evidence, calculations and deliverables |
| `research_os/state/` | Local runtime state and capability inventory |
| `ULTIMATE_CLAUDE_RESEARCH_OS_MASTER.md` | Single-file distribution and canonical specification; **not required at startup** |

## Validate the installation

From repository root with Python 3.9+:

```bash
python3 research_os/engine/verify_install.py
```

The script validates installed files and their structure, **not external API access or research accuracy**. Connections such as MCP providers may require additional installation, consent, subscriptions or credentials. Do not treat an unconnected provider as usable.

## Privacy and permissions

Research artifacts and runtime state are ignored by Git by default; review files before committing or sharing. Do not include access tokens or credentials in Markdown, source code, the repository, or responses. Tool installation, purchases and third-party actions require authorization. A Markdown-based protocol cannot guarantee perfect compliance or globally best-in-class research quality.

## Which distribution should I use?

**Use this repository** for day-to-day work. The master Markdown remains available for backups, inspection, and bootstrapping a new installation if you cannot use a ZIP/repository.
