# ATLAS Research OS — Operator Guide

A reusable methodology-first, evidence-driven research system for Claude Code. The master distribution file is `ULTIMATE_CLAUDE_RESEARCH_OS_MASTER.md`.

## Mandatory sequence
`AWAITING_INQUIRY -> INTAKE -> INTAKE_COMPLETE -> META_RESEARCH -> META_READY -> RESEARCH -> AUDIT -> DELIVERY -> LEARNING -> COMPLETE`

**Initialization**: install/verify locally, send readiness message, stop. **First user research inquiry**: launch a deep interview; ask what deliverables the user wants. **After intake**: study the best research methodology and verify tools *before* substantive research. Then execute, audit, deliver and update methods memory.

## Where things live
- `.claude/skills/`: on-demand workflows, stage-by-stage.
- `.claude/agents/`: role-specific isolated subagent contexts.
- `research_os/intake/QUESTION_BANK.md`: large adaptive interview bank.
- `research_os/policies/`: truth, tools, safety, coverage, math, scoring and quality standards.
- `research_os/domains/DOMAIN_PLAYBOOKS.md`: domain routing and specialist methods.
- `research_os/operations/STATE_MACHINE.md`: stage gates and recovery.
- `research_os/templates/`: required project artifacts and column schemas.
- `research_os/methods/`: curated cross-project methods memory. Never treat memory as current market data without refresh.
- `research_os/evaluations/`: evaluation framework and benchmark procedures.
- `research_os/engine/`: installation and project audit scripts; Python stdlib only.
- `research_os/projects/`: one folder per inquiry with evidence and outputs. May contain sensitive data: do not commit without consent.

## Starting a research project
1. After the readiness message, provide any question in ordinary language.
2. Claude will run a deep clarification interview, covering every relevant axis. You may answer in batches, write "unknown", or tell it to use justified defaults.
3. Claude writes an intake dossier and then researches how to research your question, including source, method, agent and MCP/tool selection.
4. It runs the substantive investigation, independent audits and sensitivity checks.
5. It delivers the requested formats and captures validated methodological lessons.

## Example user questions
- "Which e-commerce model has the strongest risk-adjusted opportunity in the UAE?"
- "Which 10 consumer products should we test on Amazon Saudi Arabia?"
- "How do the USA and UAE compare for a new DTC brand?"
- "Conduct a systematic review of this clinical question."

## Safe operating notes
- No hidden or automatic payments, purchases, credential requests, data exports, user impersonation or untrusted MCP installs.
- Research cannot discover inaccessible proprietary data merely by adding agents.
- Methodological rigor is assessed by evidence quality and reproducibility, not by a claimed #1 global ranking.
- You can pause any stage; project state supports recovery.
