# Canonical project layout, minimum schemas and report templates

## Directory layout per inquiry
```
research_os/projects/<date-short-title>/
  state.json
  01_intake/
    original_question.md
    answers.md
    confirmed_brief.md
    assumptions.md
    deliverables_contract.md
    open_issues.md
  02_meta_research/
    question_formalization.md
    coverage_tree.md
    method_candidates.md
    methodology_selection.md
    source_landscape.csv
    tools_registry.csv
    pilot_tests.md
    access_requests.md
    agent_plan.md
    measurement_plan.md
    verification_plan.md
    methodology_red_team.md
    research_protocol_v1.md
    readiness_gate.md
  03_research/
    branches/
    raw_evidence/
    processed_data/
    search_logs/
    calculations/
    contradictions/
    experiments/
    research_log.md
    coverage_matrix.csv
    source_registry.csv
    claim_ledger.csv
    assumptions.csv
    contradiction_register.csv
    analysis_manifest.md
    provisional_findings.md
  04_audit/
    claim_audit.csv
    coverage_audit.md
    model_audit.md
    adversarial_review.md
    security_scope_audit.md
    corrections_log.md
    quality_gate_decision.md
  05_deliverables/
    deliverable_manifest.md
    executive_decision.md
    main_report.md
    sources_and_methods.md
    user_requested_outputs/*
  06_learning/
    postmortem.md
    method_proposals.md
```
Only generate files required by the actual project; record an intentional N/A explicitly when the corresponding quality standard doesn't apply. Do not create empty files solely to pass a script.

## Source register columns
`source_id,title,author_publisher,source_url_or_file,doi_or_identifier,published_date,data_period,retrieved_date_utc,source_type,original_origin_group,geography,population,metric_definition,methodology,quality_notes,access_status,local_evidence_file,license_notes`

## Claim ledger columns
`claim_id,claim_text,claim_type,verification_status,source_ids,original_origin_groups,evidence_location,source_date,data_period,geography,units,uncertainty,contradictory_sources,reviewer,materiality,final_disposition`

## Coverage matrix columns
`coverage_id,decision_dimension,subquestion,priority,research_method,planned_sources,sources_checked,quality,unresolved_gaps,decision_impact,coverage_status`

## Tool registry columns
`tool_id,provider,capability,official_doc,access_status,region_coverage,data_type,original_vs_estimated,cost,privacy_risk,permission_needed,version,validated_at_utc,pilot_result,chosen,limitations`

## Assumptions columns
`assumption_id,description,value,units,origin,why_assumed,uncertainty_range,decision_sensitivity,validation_test,status`

## Contradiction columns
`conflict_id,claim_ids,conflicting_sources,conflict_summary,possible_cause,tests,adjudication,status,decision_effect`

## Audit columns
`claim_id,source_opened,evidence_location_verified,date_scope_verified,unit_verified,source_independence_checked,calc_reproduced,verification_status,issue_severity,review_notes`

## Deliverables contract
At minimum: requested formats, file types, report length, audience, language, citation style, rankings vs single answer, raw data inclusion, financial models, audit appendices, code, figures, packaging, constraints on sharing/licensing, acceptance criteria. The user may choose everything, some or delegate. Make defaults explicit.

## Research Protocol v1 contents
Question; purpose; comparators; population/market; horizon; outcomes; methods; retrieval plan and exact queries; inclusion/exclusion; source hierarchy; tool/access status; data dictionaries; measurement; agents/task DAG; counterevidence search; calculation/sensitivity plan; verification criteria; stopping rule; blockers; expected deliverables; version; amendment policy.

## Executive decision minimum
Decision/shortlist; why; audit level; sources as-of; key numbers with units; conditions that reverse recommendation; highest risks; unknowns; next information/experiment to acquire; reproducible model reference; complete report link.

## Research report minimum
1. Question, exact definitions and interpreted mandate.
2. Executive summary and recommendation.
3. Research scope and methodology (including Phase 0 selected method).
4. Source and data quality; evidence limitations.
5. Results by subquestion, sourced atomic claims.
6. Alternative hypotheses and contradictory evidence.
7. Quantitative and financial analysis as applicable.
8. Comparative scorecards and rank sensitivity.
9. Risk, constraints and downside.
10. Evidence-supported conclusion and confidence calibration.
11. Real-world validation tests/next actions.
12. Reproducibility and versioned audit appendix.

## Date and citation notation
Always preserve exact date/time where it matters. A source's `published_date`, `data_period` and `retrieved_date_utc` are separate. Citation should identify precise table/page/section; stable links where permitted. No placeholder URLs or invented manuscript DOIs.
