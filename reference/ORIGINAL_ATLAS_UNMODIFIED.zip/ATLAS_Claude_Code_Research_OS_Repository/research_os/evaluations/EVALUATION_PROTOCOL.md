# ATLAS private evaluation and continuous improvement protocol

## Why evaluations are mandatory
Model/vendor leaderboards test different skills than business decisions. Evaluate the complete system on practical tasks with predeclared criteria. Use factual answer and citation validation, not solely a second model's stylistic judgment.

## Benchmark construction
Maintain at least 12 diverse retrospective or answerable benchmark tasks across your recurring domains if available, with independently verified answer keys or claim-level gold standards. Include: recent public facts; numerical analysis from provided data; competing market opportunities; ambiguous user intent; country comparison; citation traps; conflicting official statistics; inaccessible-paywalled data; tool/permission failure; a scenario in which correct answer is "insufficient evidence"; adversarial prompt-injection content; and a deliberately unstable ranking.

## Scoring dimensions (suggested adjustable weights)
- 25% factual correctness of verified critical claims.
- 20% citation faithfulness (specific claims match cited locations).
- 15% decision-critical coverage/recall of known necessary evidence.
- 15% reproducible quantitative calculation and comparable data.
- 10% counterevidence and competing-explanation handling.
- 10% uncertainty calibration, overconfidence and truthful abstention.
- 5% time/cost/resource efficiency, as a tie-breaker after quality.

Scoring needs **transparent denominators** and independently adjudicated ground truth. Never invent an evaluation score. Report human reviewer agreement and uncertain items when relevant.

## A/B evaluation design
Compare existing workflow A to candidate workflow B on same question, retrieval date window, accessible datasets, quality expectations and practical budget. Blind the reviewer to system variant where feasible. Record actual models, prompts, tools, dates, tokens/spend, source lists, claims, scores and failure explanations. Avoid prompt/model data leakage and overfitting to a small set of known answers.

## Citation and claim audit protocol
Sample or fully verify claims at decision-critical level. Check link existence, source content match, geographic/time scope, original source dependencies and whether unsupported hypotheses were presented as observations. Track `verified_positive`, `partially_supported`, `unsupported`, `contradicted`, `uninspectable` with adjudicator notes.

## Method evolution protocol
Propose -> demonstrate specific failure it fixes -> run controlled test -> independent review -> adopt only if weighted score improves or risk decreases without unacceptable tradeoff -> version and document rollback. A bigger model or more agents do not automatically warrant adoption.

## Longitudinal follow-up
If real outcomes are later observed, compare forecast to actuals using appropriate error metrics and uncertainty calibration. Do not infer predictive superiority from a few successful anecdotes. Log model drift, market change and dataset revisions.

## Research evidence basis
See `REFERENCE_LIBRARY.md` for DeepTRACE, LiveDRBench, LiveResearchBench and other primary studies motivating claim-level evaluation, coverage and source fidelity. This local evaluation protocol is an engineering proposal, not a formally validated global benchmark.
