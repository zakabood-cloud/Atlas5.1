#!/usr/bin/env python3
"""ATLAS read-only installation smoke check. Python 3.9+; stdlib only."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
MANDATORY = [
    'CLAUDE.md',
    '.claude/skills/research-intake/SKILL.md',
    '.claude/skills/research-meta/SKILL.md',
    '.claude/skills/research-execute/SKILL.md',
    '.claude/skills/research-audit/SKILL.md',
    '.claude/skills/research-deliver/SKILL.md',
    '.claude/skills/research-memory/SKILL.md',
    '.claude/agents/methodology-architect.md',
    '.claude/agents/source-intelligence.md',
    '.claude/agents/tool-mcp-architect.md',
    '.claude/agents/domain-researcher.md',
    '.claude/agents/quantitative-analyst.md',
    '.claude/agents/adversarial-reviewer.md',
    '.claude/agents/evidence-auditor.md',
    '.claude/agents/report-synthesizer.md',
    'research_os/README.md',
    'research_os/operations/STATE_MACHINE.md',
    'research_os/intake/QUESTION_BANK.md',
    'research_os/policies/RESEARCH_CONSTITUTION.md',
    'research_os/policies/TOOL_AND_SOURCE_INTELLIGENCE.md',
    'research_os/policies/ORCHESTRATION_AND_SEARCH.md',
    'research_os/policies/CLAIM_AND_DATA_STANDARDS.md',
    'research_os/policies/DECISION_AND_STATISTICS.md',
    'research_os/policies/SECURITY_AND_PERMISSIONS.md',
    'research_os/policies/QUALITY_GATES.md',
    'research_os/policies/REFERENCE_LIBRARY.md',
    'research_os/domains/DOMAIN_PLAYBOOKS.md',
    'research_os/templates/PROJECT_SCHEMAS.md',
    'research_os/methods/MEMORY_POLICY.md',
    'research_os/methods/METHODS_INDEX.md',
    'research_os/evaluations/EVALUATION_PROTOCOL.md',
    'research_os/engine/audit_project.py',
]

errors = []
for filename in MANDATORY:
    path = ROOT / filename
    if not path.is_file() or path.stat().st_size < 40:
        errors.append('MISSING/EMPTY: ' + filename)
for filename in [p for p in MANDATORY if '/skills/' in p or '/agents/' in p]:
    content = (ROOT / filename).read_text(encoding='utf-8') if (ROOT / filename).exists() else ''
    if not content.startswith('---\n') or '\n---\n' not in content[4:]:
        errors.append('INVALID FRONTMATTER: ' + filename)
if (ROOT / 'CLAUDE.md').exists():
    lines = len((ROOT / 'CLAUDE.md').read_text(encoding='utf-8').splitlines())
    if lines >= 200: errors.append('CLAUDE.md too long: ' + str(lines) + ' lines (target <200)')
for filename in ['research-intake', 'research-meta', 'research-execute', 'research-audit', 'research-deliver', 'research-memory']:
    if not (ROOT / f'.claude/skills/{filename}/SKILL.md').exists():
        errors.append('SKILL NOT FOUND: ' + filename)
if errors:
    print('ATLAS INSTALL CHECK FAILED\n' + '\n'.join(errors))
    sys.exit(1)
print(f'ATLAS INSTALL CHECK PASS: {len(MANDATORY)} required files, skill frontmatter and CLAUDE.md length OK.')
print('NOTE: This check does not verify external MCP connections, actual model access or future research quality.')
