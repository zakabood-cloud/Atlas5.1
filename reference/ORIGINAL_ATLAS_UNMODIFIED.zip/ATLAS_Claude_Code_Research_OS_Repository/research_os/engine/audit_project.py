#!/usr/bin/env python3
"""ATLAS conservative project-structure/ledger audit; not a truth oracle."""
from pathlib import Path
from collections import Counter
import csv, json, sys

if len(sys.argv) != 2:
    sys.exit('Usage: python3 research_os/engine/audit_project.py research_os/projects/<project-id>')
project = Path(sys.argv[1]).resolve()
if not project.is_dir() or 'projects' not in project.parts:
    sys.exit('Expected an existing ATLAS research project directory')
issues = []
state = project / 'state.json'
if state.exists():
    try: stage = json.loads(state.read_text(encoding='utf-8')).get('stage', '?')
    except Exception as ex: issues.append('Invalid state JSON: ' + str(ex)); stage='?'
else:
    stage = '?'; issues.append('Missing project state.json')

def load_csv(rel, required):
    p = project / rel
    if not p.exists():
        issues.append('Missing ledger: ' + rel)
        return []
    try:
        with p.open(encoding='utf-8-sig', newline='') as f:
            reader = csv.DictReader(f)
            headers = reader.fieldnames or []
            for col in required:
                if col not in headers: issues.append(f'{rel} missing column: {col}')
            return list(reader)
    except Exception as ex:
        issues.append(f'{rel} cannot parse: {ex}')
        return []

if stage not in ('AWAITING_INQUIRY', 'INTAKE', 'INTAKE_COMPLETE', 'META_RESEARCH'):
    sources = load_csv('03_research/source_registry.csv', ['source_id','source_url_or_file','original_origin_group'])
    claims = load_csv('03_research/claim_ledger.csv', ['claim_id','claim_text','verification_status','source_ids','materiality'])
    sids = [r.get('source_id','').strip() for r in sources if r.get('source_id','').strip()]
    sset = set(sids)
    for sid, freq in Counter(sids).items():
        if freq > 1: issues.append(f'Duplicate source ID: {sid}')
    cids = [r.get('claim_id','').strip() for r in claims if r.get('claim_id','').strip()]
    for cid, freq in Counter(cids).items():
        if freq > 1: issues.append(f'Duplicate claim ID: {cid}')
    for r in claims:
        cid = r.get('claim_id','?')
        for sid in r.get('source_ids','').replace('|',';').split(';'):
            sid = sid.strip()
            if sid and sid not in sset:
                issues.append(f'Claim {cid} references missing source {sid}')
        materiality = r.get('materiality','').strip().lower()
        verified = r.get('verification_status','').strip().upper()
        if materiality in ('critical', 'decision-critical') and verified not in ('V2_SOURCE_MATCHED', 'V3_INDEPENDENTLY_REPLICATED', 'V2', 'V3'):
            issues.append(f'Critical claim {cid} not fully source-verified (status={verified or "missing"}); must be labeled conditional/unverified in report')
        if not r.get('claim_text','').strip(): issues.append(f'Empty claim text for {cid}')
    if not sources: issues.append('No recorded sources; cannot claim externally verified research')
    if not claims: issues.append('No claim ledger entries')
if stage in ('DELIVERY','LEARNING','COMPLETE'):
    if not (project / '01_intake/deliverables_contract.md').exists():
        issues.append('Missing deliverables contract')
    if not (project / '04_audit/quality_gate_decision.md').exists():
        issues.append('Missing audit quality-gate decision')
    if not (project / '05_deliverables/deliverable_manifest.md').exists():
        issues.append('Missing deliverable manifest')
print(f'ATLAS PROJECT AUDIT: {project.name}, stage={stage}, issues={len(issues)}')
for item in issues: print('- ' + item)
print('WARNING: passing this script only checks structural consistency; source validity, statistical integrity and compliance require independent review.')
sys.exit(1 if issues else 0)
