# Adaptive high-resolution interview question bank

**Usage:** NOT a form to dump wholesale. The Research Director maps question relevance, asks grouped questions across multiple turns, and continues until all **materially relevant** dimensions are covered. Prioritize user relevance, not a nominal number. Record answers verbatim where appropriate. Do not repeat previously answered questions. Always ask about deliverables.

## A. Question meaning and decision identity
A1. State the exact decision in one sentence: choose, rank, explain, predict, validate, discover, design or compare?
A2. What real-world action follows the report? What decision deadline applies?
A3. Is this open-ended discovery, comparison among named options, or stress-test of a favored hypothesis?
A4. Should we challenge the premise, e.g., examine alternatives outside the question?
A5. What counts as a satisfactory result? List measurable success metrics if known.
A6. Define vague terms: "best", "biggest", "profitable", "fastest", "viable", "low risk", "premium", "market leader".
A7. Should there be one final winner, a robust shortlist, conditional recommendations, or an uncertainty-based decision tree?
A8. Are there forbidden choices or requirements that cannot be compromised?
A9. Are there influential past conclusions we should independently re-evaluate rather than accept?
A10. Is the desired analysis descriptive, causal, predictive, prescriptive or exploratory?

## B. Scope, population and context
B1. Which countries, cities, regions or worldwide scope?
B2. Which population, customer segment, buyer, industry and channel? Any exclusions?
B3. Present conditions, historical period and forward horizon?
B4. B2B, B2C, B2B2C, public sector, consumer, clinical or scientific?
B5. Which market structures, company sizes, stages, legal categories or technology platforms?
B6. Comparators explicitly included or excluded?
B7. Should we test scenarios at different capital/scale levels?
B8. Should results generalize across founders or represent a specified operator?
B9. Which languages and local data markets must research cover?
B10. What currency, inflation basis, tax treatment or normalizations are required?

## C. Preferences, objective function and risk
C1. Rank maximum absolute profit, net present value, ROI, cash flow, revenue, valuation, and probability of success.
C2. What is the evaluation time horizon: 3, 12, 24, 60 months, decade?
C3. Highest upside regardless of failure, maximum median result, or strongest risk-adjusted outcome?
C4. What downside scenarios are unacceptable? Liquidity and drawdown limits?
C5. Speed to first cash flow versus long-term compounding?
C6. Capital intensity, operational complexity, dependence on specialist talent?
C7. Regulatory, reputation, product liability and ethical constraints?
C8. Is ownership/control important or are partnerships, franchises and acquisitions permitted?
C9. Is it better to maximize expected value or robustness across changing assumptions?
C10. How should subjective weights be selected: user-specified, equal, or multiple sensitivity scenarios?

## D. Resource and access map
D1. Do you have datasets, invoices, analytics, financial statements, documents, spreadsheets or prior reports available?
D2. Any specific websites, tools, MCP servers or APIs already accessible?
D3. Are there research database subscriptions or licensed datasets? Account access restrictions?
D4. Are public records, government datasets or academic databases preferred?
D5. May the system ask you to connect an external tool if evidence value is high?
D6. May the system use only free data? If not, approval ceiling per purchase/data license?
D7. Should contact with suppliers/customers/experts be suggested only, or authorized after review?
D8. May it create prototype scripts and run local analyses? Network/installation limits?
D9. What confidential data exists? What can be sent to third-party AI/data providers?
D10. Is the question urgent enough to prioritize speed over maximal breadth?

## E. Evidence, methodological and verification requirements
E1. How strict should evidence be: orientation, professional, investment-grade, systematic-review-level?
E2. Are primary sources mandatory for pivotal claims?
E3. Are preprints, vendor estimates, surveys, forum evidence, anecdotal evidence allowed—and for what purpose?
E4. How fresh must sources be? Can older foundational studies be included?
E5. Do you require independent source replication or expert validation for critical claims?
E6. Should counterarguments, failed cases and survivorship bias receive equal attention?
E7. Desired uncertainty expression: qualitative, ranges, intervals, scenarios, distributions?
E8. What minimum data and sample coverage would be persuasive?
E9. Are citations, raw search log, source-level extracts, or quoted numerical tables required?
E10. Is a reproducible protocol and data provenance dossier necessary?

## F. Research breadth and depth
F1. What is the initial candidate universe? Any seed candidates?
F2. Should we examine adjacent categories, second-order substitutes and disruptive alternatives?
F3. Are constrained screening stages preferred (e.g., 100 -> 30 -> 10 -> 3)?
F4. Which exact disqualifiers should be applied early versus verified later?
F5. Need competitive comparisons across multiple countries/channels/customer segments?
F6. Should we investigate emerging or speculative opportunities separately from established ones?
F7. Do we need exact country-specific market-entry regulations?
F8. Need supply-side and demand-side analysis, or just one?
F9. Need scenario stress tests under macroeconomic or platform changes?
F10. How much evidence must be gathered per finalist to justify a ranking?

## G. Deliverables — ALWAYS ASK, FIRST ROUND
G1. Which outputs: executive answer; long report; academic-style synthesis; investor memo; procurement dossier; playbook; step-by-step execution plan?
G2. Which FILE FORMATS: Markdown, PDF, DOCX, HTML, PPTX, XLSX, CSV, JSON, Python notebooks, ZIP, or only chat?
G3. Report structure: concise top-line first, long appendix, detailed section-by-section, interactive dashboard?
G4. Approximate length: pages, word count, or unlimited subject to relevance?
G5. Would you like raw data and source extracts, or only interpreted data and citations?
G6. Include all URLs, access timestamps, original quotes/locations, and source verification status?
G7. Include executable financial models and assumptions, scenario calculator and sensitivity visuals?
G8. Include a ranked shortlist, 1 winner, decision tree, confidence ratings or all?
G9. Include adversarial arguments, reasons not to proceed, uncertainty and counterfactuals?
G10. Include vendor/supplier outreach templates, market tests, implementation roadmap, or business plans?
G11. Preferred language, regional number/currency conventions and audience sophistication?
G12. Is this for personal reading, professional review, a board, potential investors, or public publishing?
G13. Do you require editable artifacts, print-ready layouts, presentation graphics or copy-paste scripts?
G14. Should deliverables include methodology appendix, search log, data dictionary, tests and version history?
G15. What should be prominently summarized on page one? What should be omitted entirely?

## H. Operational authorization and boundaries
H1. Approximate maximum research spending, if any? Never infer a purchase approval.
H2. Can the system suggest purchases with costs and benefits for explicit later approval?
H3. Which sites/tools are off-limits?
H4. Can it browse public sites and use official free APIs subject to terms?
H5. May it install vetted open-source packages with approval, or only use present environment?
H6. May it use multiple external AI APIs if connected, or must all analysis stay in Claude?
H7. Should sensitive data remain local? Do provider policies constrain transfers?
H8. Can it execute real ads, purchase samples, contact suppliers or create accounts? If so each operation still needs explicit task-specific approval.
H9. Should it run until research coverage saturates, or within a user-defined computational / time budget?
H10. Does the user want staged checkpoints, or autonomous continuation after intake within permissions?

## I. Domain branch — e-commerce and product selection
I1. Platform Amazon, Shopify, Noon, TikTok Shop, marketplaces, wholesale or cross-channel?
I2. Product categories including regulated/seasonal/hazardous excluded or investigated as risk cases?
I3. Physical versus digital, services, subscriptions, replenishment, accessories?
I4. Existing demand versus new category innovation? MVP/OEM/ODM/private label/dropshipping?
I5. Price, contribution margin and desired repeat purchasing?
I6. Brand differentiation requirements, patents/trademarks, certification constraints?
I7. Shipping origin, destination, customs, taxes, returns, cash-on-delivery?
I8. Preferred supplier MOQ, lead times, inventory funding and payment terms?
I9. Organic versus paid acquisition, influencer strategy, target CAC and expected LTV?
I10. Consumer needs, use cases, complaints and review mining?
I11. Seasonality, product lifespan, platform risk, seller concentration?
I12. Should actual supplier quotes or proof-of-demand experiments be proposed?
I13. Which product dimensions, weights, breakage or restricted categories to screen?
I14. Is scaling to GCC/USA/Europe in scope?
I15. Should product selection prioritize tested profitability or differentiated brand equity?

## J. Domain branch — starting or acquiring a business
J1. New venture, business acquisition, franchise, agency, software or asset ownership?
J2. What business-stage maturity and time-to-profit constraints?
J3. Recurring revenue, asset-light versus capital-intensive, staff requirements?
J4. Highest total wealth vs cash distribution vs risk-adjusted return?
J5. Allowed leverage/financing, ownership and dilution?
J6. Competitive moat, network effects, switching costs, pricing power and regulation?
J7. Need modeled unit economics, acquisition price multiples, valuations and exit scenarios?
J8. What owner involvement is assumed; owner-operator versus absentee investor?
J9. Which territories' licensing and corporate structures matter?
J10. Do we include failure distributions and survivorship bias?

## K. Domain branch — market/country comparison
K1. Customer demand per capita vs total addressable demand?
K2. Consumer price levels, income, disposable spending, payment preferences?
K3. Competitor density, incumbent concentration, channel penetration?
K4. Local advertising prices, click rates, conversion and retention, sampled by segment?
K5. Import/export, corporate tax, VAT/sales tax, product compliance, registration?
K6. Currency and FX exposures, capital mobility and payment settlement?
K7. Fulfillment, warehousing, delivery/returns and last-mile service?
K8. Cross-border entry friction, language localization and customer service?
K9. Should reachability and entrant economics dominate raw market size?
K10. Can the comparison be built using the exact same product and standardized cost assumptions?

## L. Domain branch — investment and finance
L1. Public equities, private equity, VC, debt, real estate, derivatives or business ownership?
L2. Benchmark, investable universe, denomination and liquidity needs?
L3. Risk metrics: volatility, drawdown, ruin probability, downside capital loss?
L4. Quality of earnings, cash conversion, dilution, valuation and comparable transactions?
L5. Accounting definitions, fiscal periods and source filings required?
L6. Macro scenarios, rates, inflation, FX, policy sensitivities?
L7. Ex-ante expectations versus ex-post historical backtests?
L8. Fees, taxes, financing and transaction costs?
L9. Bias controls: look-ahead, survivor, publication, sample-selection, overfitting?
L10. What would invalidate the investment thesis?

## M. Domain branch — scientific, clinical and technical
M1. PICO/PECO/Population-Intervention-Comparator-Outcome or alternative structured question?
M2. Human/animal/in-vitro/computational evidence scope? Eligible study designs?
M3. Desired outcomes, follow-up, effect thresholds and harms?
M4. Date/language restrictions and grey literature inclusion?
M5. Systematic review, scoping review, umbrella review, narrative review or technical survey?
M6. Is meta-analysis statistically and conceptually appropriate?
M7. Risk-of-bias tool, applicability, publication bias and heterogeneity assessment?
M8. DOI/PMID, protocol registration, PRISMA and GRADE reporting requirements?
M9. Standards, equipment versions, clinical guidelines and regulatory approvals?
M10. Is independent professional interpretation required for decision use?

## N. Final convergence questions
N1. Which uncertainties are still most important to the decision?
N2. What result would surprise you enough to change your original view?
N3. May the research conclude "insufficient evidence" or "none of the candidates"?
N4. Should next steps involve real-world validation, and what scale is permitted?
N5. Here is the interpreted mandate; what is inaccurate, missing or incorrectly prioritized?

## Intake summary template
`Goal / Decision / Scope / Exclusions / Comparators / Metrics / Horizon / Evidence standard / Available inputs / Permissions / Cost policy / Deliverables / Detail / Language / Critical ambiguities / Defaults / Topics explicitly not to personalize`.
