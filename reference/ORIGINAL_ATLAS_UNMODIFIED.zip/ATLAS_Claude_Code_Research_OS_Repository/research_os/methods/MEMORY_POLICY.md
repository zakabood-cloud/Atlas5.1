# Multi-layer research memory policy

## Four memory layers
1. **Immutable provenance / project evidence:** dated source documents, user-approved project data, claim ledgers, runs and analysis artifacts; belongs only in the project, subject to retention/privacy policy.
2. **Persistent project state:** inquiry, intake answers, assumptions, status and task checkpoints; used to resume this project. Never generalize it silently.
3. **Curated domain methods memory:** verified methods, search recipes, measurement definitions, data provider caveats, failure modes and revalidation triggers; version controlled and shared only if suitable.
4. **Subagent persistent memory:** Claude Code `memory: project` may help recurring specialist roles, but its notes are advisory and must not override curated policy or serve as factual evidence.

## Memory object schema
`id,domain,question_class,method,why_it_works,evaluation_evidence,source_refs,date_added,last_verified,valid_until_or_review_trigger,tool_dependencies,applicability,known_failure_modes,conflicting_methods,confidentiality,status,version,owner`.

## Provenance and freshness
Mark `CANDIDATE`, `VALIDATED`, `REVALIDATE`, `DEPRECATED`, `REJECTED`. Do not install unsupported rule changes. Favor generalized research procedures over transient vendor market share or product facts. Use short index with links to full memory, not an ever-growing Claude.md.

## Data governance
User-provided sensitive data, health records, financial accounts, privileged legal communications, identities, location/address, trade secrets and source credentials are not automatically promoted to shared memory. Determine consent, access rights, storage and retention. Ensure `.gitignore` prevents accidental commits. De-identify where appropriate.

## Measuring progress
Create baseline and follow-up evaluations on the same held-out task set. Compare factual accuracy, citation audit pass rate, coverage, computation correctness, calibration, cost and practical decision utility. Record uncertainty in measured improvements; no claims of self-improvement without evaluation. Keep changelog and rollback.
