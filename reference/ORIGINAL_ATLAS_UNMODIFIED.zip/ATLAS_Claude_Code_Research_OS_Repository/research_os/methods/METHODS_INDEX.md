# ATLAS methods index — curated, versioned knowledge

This file is initially empty by design. It is **not** a place for permanent market facts or unverified past reports. Add entries only after review using `research_os/methods/MEMORY_POLICY.md`.

| Method ID | Domain | Question class | Evidence status | Last verified | Applicability / limitations | Detail file |
|---|---|---|---|---|---|---|

## Candidate methods (unverified)
None yet. Do not invent evidence from non-existent past investigations.

## Revalidation queue
None yet.
