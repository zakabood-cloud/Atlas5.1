# Domain-specific methodological router

The research domain changes measurement and evidence standards. During Phase 0 select/compose relevant modules; confirm against primary methodology resources and current data access. A domain playbook is a **starting protocol**, not a substitute for question-specific meta-research.

## 1. Product discovery / Amazon / marketplace
Decision units: customer jobs, product-category-segment, SKU, geography, marketplace/channel and business model. Candidate discovery -> consumer unmet need -> observed demand proxies -> competitor landscape -> differentiability/IP/regulation -> sourcing feasibility -> unit economics -> acquisition/organic channel -> working capital -> negative reviews/returns -> controlled validation plan. Evaluate demand **against** supply, not only search popularity. Recognize seller-reported actual sales versus third-party modeled volumes. Calculate landed costs, referral/fulfillment/storage/advertising/returns taxes, and channel-dependent net contribution. Investigate rank/review advantages and structural barriers for entrants. Choose finalists with comparable assumptions. Escalate exact supplier claims for written quotations and compliance checks.

## 2. Shopify/DTC / omnichannel
Distinguish commodity arbitrage from proprietary brand; assess addressable audience, traffic acquisition, paid and organic CAC, conversion, AOV, contribution margin, cohort retention, repeat purchase, refund rate, creative fatigue, payment fees, fulfillment, inventory, cash cycle, brand moat, channel concentration and cross-border friction. If no first-party paid-ad results exist, treat CAC as a scenario to be tested, not fact. Compare Amazon and Shopify on equivalent product, price and operating definitions; quantify marketplace versus DTC effects and brand control.

## 3. Countries and geographical opportunities
Normalize reference population, FX, taxes, price levels, timing and regulatory definitions. Compare reachable market, not just total market size. Examine consumer income/spending, e-commerce usage, demand by category, logistics, local language, payment habits, channel fees, competitive concentration, staffing, corporate formation, import compliance and enforcement. Compare **same hypothetical entrant/product** under each market using standard assumptions plus market-specific estimates. Use official country statistics and grounded empirical estimates when possible. Present conditional winners by entry strategy and risk profile.

## 4. Highest-profit businesses / wealth-generation strategy
Separate theoretical ceiling, median attainable outcome, early cash flow, operating margin, return on invested capital, risk-adjusted wealth, scalability, ownership dilution, probability of total failure and exit valuation. Beware survivorship bias from billion-dollar winners. Segment opportunity by capital tiers, technical capabilities and business stage (without imposing any user's own constraints unless requested). Use observed sector returns/margins carefully; incumbent public-company margins do not imply a startup entrant's profits. Compare opportunity by unit economics, addressability, customer acquisition, moat, operating complexity and capital/cash-cycle dynamics. Avoid unsupported "one best business globally" conclusions; return robust sets and empirical validation paths.

## 5. Business acquisitions / private equity / investment due diligence
Review primary statements, quality-of-earnings, normalized EBITDA, gross-to-net revenue, working capital, customer/vendor concentration, receivables aging, liabilities, cash flows, leverage, owner dependency, churn, legal/regulatory exposure and tax. Stress-test valuation, exit multiple, financing covenants and downside. Public investable research: original filings, dilution, debt maturities, governance, valuation and consensus assumptions; avoid look-ahead in backtests. Clearly flag private numbers requiring NDA or professional diligence.

## 6. Scientific / health / clinical effectiveness
Formalize PICO/PECO and protocol. Search bibliographic databases, trial registries, guidelines and grey literature as warranted. Assess design, selection and publication bias, protocol deviations, missing outcomes, heterogeneity, harms, generalizability and certainty of evidence. Use PRISMA/PRISMA-S for an actual systematic review and relevant Cochrane and GRADE methods when applicable; do not misapply as general report badges. Use DOI/PMID and validate source title, date and exact results. Do not synthesize numerically unless studies are sufficiently comparable and effect sizes/variance valid. Reference professional guidance where decisions affect patients.

## 7. Regulatory / legal / policy
Locate exact official law/standard, effective date, jurisdiction, agency notices, exemptions, translations, enforcement and court/regulator interpretation where necessary. Distinguish law, policy, guideline, commentary and vendor advice. Use counsel for high-stakes legal conclusions. Periodically recheck official updates; one generic website can omit critical local exceptions.

## 8. Engineering / product and technology comparison
Specify acceptance criteria, technical standards, primary spec sheets, versions, reproducible experiments, failure conditions, performance under representative workloads, supply chain and operating cost. Distinguish vendor specifications from field-tested performance and marketing claims. Evaluate interoperability, security, documentation, support, lifecycle and regulatory compatibility.

## 9. Competitive intelligence and marketing
Identify direct, indirect and substitute competitors; source actual prices, SKUs, product pages, ads and public business information. Web traffic, keyword volumes and ad libraries are **proxies** for exposure/interest and do not reveal reliable ROAS or profit alone. Cross-check with customer research, observed funnel metrics and market structure. Avoid collecting private personal data or violating platform terms. Design experiment proposals to discover CAC/conversion and measure results against test thresholds.

## 10. Multi-domain questions
Split into dimensions with coherent sub-methods and a common decision definition. Ensure terms align across branches: dates, markets, currency, costs, sampling scope and evidence hierarchy. Synthesize as conditional decision analysis; do not mechanically average incompatible domain scores.
