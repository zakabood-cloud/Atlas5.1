# Lifecycle, stage transitions and resumability

## State contract
Source of truth: `research_os/state/engine_state.json` for global stage; `research_os/projects/<id>/state.json` for project stage. Store JSON with keys `version`, `project_id`, `stage`, `created_at_utc`, `updated_at_utc`, `objective`, `pending_questions`, `open_blockers`, `finished_gates`, `next_action`, `budget_status`, `evidence_freshness_as_of`, `methods_version`. Never write fabricated timestamps. Update atomically (temporary file + rename) if scripting.

## Hard transition rules
| From | To | Required proof |
|---|---|---|
| Uninstalled | AWAITING_INQUIRY | Files installed, verify script passed, capability inventory recorded, readiness message sent |
| AWAITING_INQUIRY | INTAKE | User submits a new actual research question, not just a greeting |
| INTAKE | INTAKE_COMPLETE | Explicit objectives and deliverables captured; all material ambiguity addressed or labeled as assumption; interview summary written |
| INTAKE_COMPLETE | META_RESEARCH | User answered or intentionally skipped relevant questions; no premature topic searches |
| META_RESEARCH | META_READY | Preparation dossier, access-tested tool matrix, method selection, feasibility, coverage and red-team method critique |
| META_READY | RESEARCH | Research protocol frozen/versioned; access/permission blockers resolved or fallbacks declared |
| RESEARCH | AUDIT | Discovery, extraction, calculations, contradictory evidence and source files saved; unresolved issues registered |
| AUDIT | DELIVERY | Independent critical-claim audit complete; numerical outputs reproducible; limitations exposed |
| DELIVERY | LEARNING | Requested files rendered/validated; executive summary and audit appendix complete |
| LEARNING | COMPLETE | Memory proposal adjudicated; state saved; system offers a new inquiry |

## Additional states
- `WAITING_FOR_USER`: missing essential answers or permission; no hidden continuation.
- `BLOCKED`: tool/data access prevents defined requirement; present alternatives and explicit scope downgrade.
- `PAUSED`: user pause; preserve checkpoint.
- `ABORTED`: user cancellation, stop and preserve authorized files.
- `PARTIAL_COMPLETE`: investigation exhausted accessible evidence but cannot satisfy one or more quality gates; transparent partial output.

## Interview-first is inviolable
At `INTAKE`, no web searches, source retrieval, specialist agent research, data-provider calls or meta-research. Local question clarification and user-answer recording only. **Meta-research also counts as research** and cannot start until intake finishes. Interview all necessary dimensions, even if inquiry looks precise. Use the bank without generating repetitive questions.

## No accidental first-run research
When master file is opened for initialization, always end with readiness announcement and wait for a **separate user message** containing the question. If the same user message contains a topic alongside initialization, prioritize the explicit initialization contract and mention the question can be resubmitted after readiness unless the user explicitly overrides this sequence.

## Restart behavior
Read state; inspect actual artifacts. Never assume a finished task exists because a text file says it does. Repair missing files and recheck tool connections on each relevant stage. Resume at the first incomplete gate, not at the beginning. If project methodology changed, record amendment and rescore affected conclusions. Reconfirm missing permissions only when necessary.

## Completion is finite
Use adaptive saturation and decision-impact stopping rules, not infinite requests for "maximum research". Meaningful new independent sources, sensitivity to missing assumptions, access constraints, quality gates and user budget govern stopping. Never falsely announce 100% coverage of the unknowable internet. Keep a list of unsearched or inaccessible sources.
