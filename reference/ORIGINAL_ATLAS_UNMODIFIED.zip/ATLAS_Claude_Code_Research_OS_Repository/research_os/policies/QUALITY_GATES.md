# Stage quality gates — measurable criteria and stop rules

## Gate I — User-intent validity
Must have explicit/assumed objective, comparators, scope, timeframe, exclusions, key constraints, permission policy and **deliverables contract**. All user answers tracked, contradictions reconciled, material unknowns visible. No topical web research before this gate.

## Gate M — Method readiness
Formal research question; at least one justified methodology; method alternatives examined for consequential tasks; explicit evidence selection; source availability and expected coverage; tool candidates and real access statuses; feasibility pilots for critical tools; research agent graph; analysis and verification plan; limitations; adversarial critique; documented research protocol. Fails if a required paid dataset is casually assumed accessible.

## Gate R — Evidence sufficiency
Each pivotal outcome criterion investigated or explicitly missing; candidate funnel documented; core sources and data inspected; counterevidence searched; original-source dependencies identified; calculations possible/recorded; no evidence-free winner. Evidence saturation measured relative to **defined decision dimensions**, not the whole universe.

## Gate V — Verification quality
All decision-critical factual and numerical claims inspected against source locations or labeled unverified; important calculations rerun; sensitivity, counterexample and temporal checks; report citations traceable; current standards where relevant; risk, assumptions and missing data prominent.

## Gate D — Deliverables fulfilled
Every user-chosen format generated or clearly marked unavailable; content matches evidence; tables and plots accurate and labeled; files readable; executive summary cites major evidence; appendices and ledgers available; report explicitly states research dates, methods, access, known constraints and confidence.

## Gate L — Memory quality
Only generalized methods with evidence provenance, validation result, applicability limits, date and review trigger go into reusable memory. Project-specific sensitive facts are not promoted. A procedural improvement must pass at least one regression test or remain a proposed improvement.

## Issue severity
`BLOCKER`: invalidates decision or demands unavailable permission; `CRITICAL`: could flip outcome or mislead financially/clinically; `MAJOR`: meaningful missing evidence; `MINOR`: presentation/local issue. Every `BLOCKER` must have explicit user-visible treatment; every `CRITICAL` needs correction or clear report warning before strong conclusions.

## Adaptive stopping rule
At each iteration compare **expected value of additional information** with cost/time/access and risk of a wrong decision. If the leading ranking remains unstable across plausible assumptions, do not force closure; focus on the variable that could change it. If no accessible sources can resolve it, recommend an empirical test. Mark `PARTIAL_COMPLETE` rather than claiming exhaustive verification.

## Illustrative audit targets (customize to stakes)
- 100% of **decision-critical** numerical claims have traceable evidence or are explicitly assumed and modeled.
- 100% of actual calculated numbers in the final recommendation are reproducible or clearly marked manual/approximate.
- 100% of identified blocking contradictions have disposition: resolved, conditional, or unresolved.
- Pivotal rankings survive at least one sensible adverse sensitivity case **or are labeled fragile**.
- No claim of cross-model independence unless separate models were actually called; no claim of source independence if upstream origin shared.

These targets describe process completeness, not an objective percentage measure of truth or global research exhaustiveness.
