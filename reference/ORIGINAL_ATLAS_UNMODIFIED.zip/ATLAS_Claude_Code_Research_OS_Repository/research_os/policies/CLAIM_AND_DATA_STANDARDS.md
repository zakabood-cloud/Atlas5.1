# Evidence pipeline, provenance and claim verification

## Unique identifiers
`SRC-0001` source document; `ORIG-0001` originating information; `CLAIM-0001` atomic assertion; `DATA-0001` dataset; `MODEL-0001` calculation artifact; `DEC-0001` decision-relevant conclusion. Preserve stable references within a project.

## Source ledger
Each source: ID, title, author/publisher, source type, exact URL/DOI/file hash where possible, retrieval date UTC, publication/revision date, data period, geo/population, data-collection method, original producer, cited upstream origin, trust/issues, access/paywall/license, relevant precise passages or tables and provenance chain. Never list an unvisited URL as reviewed.

## Claim ledger
Each claim: exact testable text (split compound claims), claim type/status, source IDs, original-origin group IDs, evidence location, direct quote/extract within copyright limits, supporting/contradicting evidence, independent check status, numeric values/units/dates, uncertainty and final inclusion decision.

## Verification statuses
- `V0_UNCHECKED`: generated assertion or source pointer without inspection.
- `V1_SOURCE_FOUND`: source exists, but whether it supports the claim not confirmed.
- `V2_SOURCE_MATCHED`: exact relevant location inspected, supports the claim as stated including date, units, geography and caveats.
- `V3_INDEPENDENTLY_REPLICATED`: a separate original evidence family or reproducible calculation supports the same scoped result.
- `X_CONTRADICTED`: strong contrary source or measurement mismatch; unresolved until adjudicated.
- `X_INVALID`: source nonexistent, mismatched, or calculation disproven.
A V3 status is not required or always possible; do not pretend it is. A critical claim needs V2 or a conspicuous caveat before confident use. Do not label a secondary model estimate as a verified observed financial fact simply because its cited table was matched.

## Traceable report citation rule
Every pivotal factual or numerical sentence needs an adjacent specific citation/footnote tied to the source ledger. Cite the **exact report, page/table/section/anchor** where possible. If a source is a supplied private file, cite the exact file path/page or section and respect access constraints. Avoid dangling generic homepage links, citation laundering, circular citations, AI-generated references and irrelevant "support". Citation correctness is separate from the claim's truth.

## Tables and calculations
Each numeric column must specify unit, currency, price-year, geography, sampling window, observational/estimated status and source. Join keys and exclusion rules should be documented; avoid mixing nominal and real values. For vendor estimates, preserve vendor's limitations and sampling/estimation basis. Use transparent formulas in code for derived numbers.

## Conflict adjudication
Compare exact definitions, numerator/denominator, reference dates, coverage, revision history, sample method and source independence. Choose stronger evidence if justified, but preserve credible disagreement and alternative plausible values. A contradiction is not automatically fixed by averaging incompatible estimates.

## Critical claim sampling and exhaustive checks
List claims that control final rankings, downside or recommendations; verify **every** critical claim. For noncritical details, stratify samples for audit and report the sampling fraction and issue rate. Never claim the entire document was validated when only a sample was checked.

## Record freshness
Source retrieval date is not publication date; publication date is not data collection date. Check policy and model/version changes at time of use; tag uncertain freshness and plan recheck. Save query, date and original relevant excerpts to support replication where licensing permits.
