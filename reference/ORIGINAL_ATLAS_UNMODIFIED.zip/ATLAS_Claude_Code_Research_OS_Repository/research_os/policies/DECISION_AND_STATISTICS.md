# Decision analysis, economic modeling and numerical quality

## Decision framing
Separate (1) feasible alternatives; (2) facts/estimates about their consequences; (3) user preferences and weights; (4) uncertainty and information gaps. Always compare like-for-like scope and assumptions. Distinguish maximizing overall wealth from maximizing average ROI, near-term cash flow, valuation or likelihood of success.

## Ranking and scoring discipline
- Define objective metrics before scoring. Normalize only comparable variables; never hide subjective preferences as "objective weighted scores".
- Use multiple weight sets and scenario assumptions. Display rank stability, not only the champion.
- Consider Pareto frontier when no single option dominates on all relevant dimensions.
- Preserve disqualified candidates and objective reasons. If a plausible alternative was excluded because data was missing, record that as unresolved rather than a negative score.
- Test whether plausible uncertainty interval overlap prevents a decisive winner.

## Financial model minimum for business/product investigations
Concretely calculate: net selling price after tax/refunds/discounts; COGS; shipping, duty and landed cost; variable fulfillment; platform fees; payments; advertising/CAC; returns and replacement costs; contribution per order; fixed operating costs; margin; working capital; inventory turns; cash conversion; payback; ramp; downside; capital employed; tax assumptions; regulatory costs. Distinguish recurring revenue from recurring **profit**. Model failed launches and discontinued SKUs where data allows.

## Market sizing
Triangulate top-down TAM and bottom-up obtainable market. Do not use global market CAGR as a proxy for entrant opportunity. Show addressability, market-access constraints and sales capture conditions. Keep platform search interest, product reviews, traffic estimates and keyword volume distinct from actual transaction/sales/profit.

## Statistical and causal quality
- Check appropriate reference population, denominators, sampling frame, confounding, missing data, multiple comparisons and selection effects.
- Causal claims require stronger design than correlation, before/after or testimonials.
- Forecasts disclose structural assumptions and fit diagnostics, holdout/out-of-time tests where feasible; prevent look-ahead, leakage and survivorship biases.
- Use bootstrapping/Bayesian/Monte Carlo only when distributional assumptions have defensible inputs. Simulation cannot create evidence.
- Show uncertainty intervals where meaningful, not fake precision (e.g., 86.347% probability from subjective guesses).

## Model audit procedure
1. Input provenance and assumptions ledger.
2. Currency/date/inflation/tax normalization.
3. Unit tests for formula identities and extreme cases (zero sales, 100% returns, rising CAC, doubling costs).
4. Independent recalculation of key outputs (separate script or distinct reviewer).
5. Sensitivity tornado or grid (key drivers) and stress cases.
6. Breakeven feasibility, capital runway and downside logic.
7. Decisions at probability ranges if justified; label subjective probability calibration.
8. Model limitations and how real-world tests could improve it.

## Value of information
Prioritize missing facts according to: decision sensitivity, uncertainty magnitude, attainable measurement quality, cost, lead time and side effects. Recommend experiments with pre-specified pass/fail thresholds (pilot ads, supplier bids, customer tests, interviews, primary data collection). Never execute real spending or external contact without specific approval.

## No fake universal winner
If multiple business models are efficient under different capital, skills, geographies or risk preferences, report those conditional winners. If the question deliberately excludes the user's circumstances, present standardized scenarios and avoid pretending one context is universal.
