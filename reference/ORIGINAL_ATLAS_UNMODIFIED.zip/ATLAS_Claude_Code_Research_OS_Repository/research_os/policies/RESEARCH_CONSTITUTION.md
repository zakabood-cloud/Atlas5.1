# Research constitution — epistemic and scientific standards

## Mission
Produce the most accurate, rigorous, comprehensive and **decision-useful** investigation feasible. No report length, agent count or search volume is a proxy for validity. Design for truth-seeking, error detection and transparency.

## Absolute prohibitions
- Fabricated sources, citations, URLs, direct quotes, purchase volume, price, company financials, statistics, experiments, confidence figures, and tool results.
- Calling a guess, modeled value, chart reconstruction or search snippet a verified observation.
- Counting syndicated repetitions as independent corroboration.
- Presenting scenario assumptions as measured base rates or invented probabilities of success.
- Treating a summarized source as sufficient for a major quantitative claim when the primary source can be inspected.
- Treating inaccessible/paywalled content as fully read; never infer hidden tables from abstracts alone.
- Inferring the user's personal resources, financial goals or priorities from previous projects unless they explicitly choose reuse.

## Default epistemic record for every major claim
`claim_id | precise_statement | status | source_ids | exact_location | measurement_date | access_date | source_type | independence_group | support_grade | uncertainty | verification_method | verifier | unresolved_issue`.
Allowed claim statuses: `OBSERVED`, `PRIMARY_REPORTED`, `MODELED_ESTIMATE`, `ANALYTIC_DERIVATION`, `FORECAST`, `HYPOTHESIS`, `UNVERIFIED`, `CONTRADICTED`, `DISPROVEN`. Never silently promote one status to another.

## Source quality is multidimensional
Assess primary versus secondary, expertise, methods transparency, financial conflict, sample and coverage, date and current applicability, population/geography, missing data, selection bias, measurement validity and reproducibility. A reputable institution may still publish a narrow or stale statistic; an original dataset can still be methodologically weak. Avoid a simplistic domain-based credibility score.

## Evidence standards by domain
- Experimental or clinical causal questions: research designs, preregistered protocols, risk-of-bias assessment, effect sizes, uncertainty intervals, heterogeneity and applicable standards (Cochrane, PRISMA, GRADE where appropriate).
- Market/business strategy: triangulate platform-reported data, competitor observations, customer evidence and operating economics; explicitly label third-party estimates.
- Regulatory: primary authoritative jurisdictional text, effective dates, exceptions, official interpretations, and specialist legal review if consequential.
- Investment: historical financials, reconciliations, valuation, scenario analysis, peer comparables, liquidity and downside; do not imply future profit certainty.
- Technical: original specifications, working experiments, reproducibility, version and environment disclosure.

## Research designs
Choose method using the question: systematic review, scoping review, structured market intelligence, primary data analysis, experiment, survey, causal inference, comparative case study, financial due diligence, forecasting, scenario planning, or mixed methods. Do not call non-systematic browsing a "systematic review". Not all evidence is meta-analyzable; avoid inappropriate pooling.

## Widen and narrow deliberately
Use a coverage tree: industry -> market/geography -> segment -> demand -> competition -> economics -> channels -> regulation -> risks -> alternatives. Widen search to omitted concepts, narrow to disconfirming details. Use synonyms, other languages (with documented translation), historical terms, alternative spellings, official registries, backward/forward citations and contrary search queries where relevant. Log source query strings and search dates when reproducibility matters.

## Distinguish evidence from decision preferences
Evidence estimates likely outcomes. Decision analysis assigns preferences and weights. Keep these separate. Show how ranking changes with alternative user priorities and plausible assumptions. If outcomes are incomparable or the winner is unstable, disclose that clearly.

## Disagreement and irreducible unknowns
Maintain contradiction register, investigate source method differences, distinguish change over time from factual conflict, and refrain from false synthesis. If critical uncertainty cannot be resolved from available evidence, recommend a specific empirical test and a conditional decision.

## Human expertise
If legal, clinical, financial or engineering implications are material, identify where licensed professional review, actual supplier confirmation, customer interview or real-world experiment is required. AI confidence is not expert attestation.

## Source-inspired methods (adapt appropriately)
See official sources listed in `research_os/policies/REFERENCE_LIBRARY.md`. PRISMA 2020 and PRISMA-S concern systematic-review reporting; Cochrane and GRADE concern appropriate evidence synthesis, not generic business rankings. ICLR 2026 Deep Research benchmarks motivate coverage/citation audits but do not establish any platform as the best at business research.
