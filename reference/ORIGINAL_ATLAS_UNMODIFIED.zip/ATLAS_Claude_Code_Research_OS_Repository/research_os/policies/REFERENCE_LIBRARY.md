# Methodological references — source anchors (verify again when used)

These are **methodology references**, not proof that any single AI model or this OS is the highest-performing research platform. The sources below were reviewed when this master specification was prepared (2026-11-03). Revisit official sites and version dates when designing each new project. Avoid copying long copyrighted material.

## Claude Code implementation
- Project instructions, loading and auto memory: https://code.claude.com/docs/en/memory — project `CLAUDE.md` target under 200 lines; use skills and structured memories instead of huge always-on prompts.
- Skills and progressive context loading: https://code.claude.com/docs/en/skills — project skills under `.claude/skills/<name>/SKILL.md`, YAML frontmatter, manual/automatic invocation.
- Subagents and memory scope: https://code.claude.com/docs/en/sub-agents — scoped roles with isolated context and optional `memory: project`.
- Agent teams: https://code.claude.com/docs/en/agent-teams — experimental, not always enabled; use only when peer collaboration justifies cost.
- MCP configuration and scope: https://code.claude.com/docs/en/mcp — project `.mcp.json`; credentials/approval required, server status is not guaranteed.
- Capabilities comparison: https://code.claude.com/docs/en/features-overview — understand what belongs in CLAUDE.md, skills, subagents, hooks and MCP.
- Hooks: https://code.claude.com/docs/en/hooks — optional machine-enforced checks; do not auto-install untested scripts.

## Search coverage and reliable synthesis
- ICLR 2026 *Characterizing Deep Research: A Benchmark and Formal Definition*: https://proceedings.iclr.cc/paper_files/paper/2026/hash/114e1dc345fe31b8b9b0c6f7b55a0644-Abstract-Conference.html — extensive concept coverage, claim discovery and missed queries.
- ICLR 2026 *LiveResearchBench*: https://proceedings.iclr.cc/paper_files/paper/2026/hash/998f8d8ff2697da2eae5f87143668754-Abstract-Conference.html — user-centric current research, coverage, citation association, correctness and report-level evaluation.
- ICLR 2026 *DeepTRACE*: https://proceedings.iclr.cc/paper_files/paper/2026/hash/ad08767706825033b99122332293033d-Abstract-Conference.html — claim-level citation support auditing and sourcing failure modes.
- ACL 2026 *DeepFact*: https://aclanthology.org/2026.acl-long.1586/ — audit-then-score factuality benchmarking, importance of reviewable evidence disputes.
- EMNLP 2026 *Who is the Agent to Blame?*: https://aclanthology.org/2026.emnlp-main.1681/ — citation/faithfulness mistakes introduced during multi-agent handoffs.

## Research-method standards (use only where appropriate)
- PRISMA 2020 systematic-review reporting: https://www.prisma-statement.org/prisma-2020; BMJ DOI: https://doi.org/10.1136/bmj.n71.
- PRISMA-S literature-search reporting: https://www.prisma-statement.org/prisma-search; DOI https://doi.org/10.1186/s13643-020-01542-z.
- Cochrane Handbook and search planning: https://www.cochrane.org/handbook and https://www.cochrane.org/authors/handbooks-and-manuals/handbook/current/chapter-04.
- GRADE evidence certainty: https://www.cochrane.org/learn/courses-and-resources/cochrane-methodology/grade-approach/grade-handbook and https://book.gradepro.org/.
- NIST AI RMF Generative AI Profile: https://doi.org/10.6028/NIST.AI.600-1.

## Security and external tool trust
- OWASP MCP Security Cheat Sheet: https://cheatsheetseries.owasp.org/cheatsheets/MCP_Security_Cheat_Sheet.html — tool access control, prompt injection, logging, consent and source provenance.
- OWASP AI Agent and MCP Security: https://owasp.github.io/DevSecOpsGuideline/2-Process/2-2-Develop/2-2-5-AI-Agent-and-MCP-Security/ — least agency, malicious MCP metadata, remote execution and secret exposure.

## Interpretation caution
These references justify **specific design principles**, not the assertion that ATLAS universally outperforms other workflows. Verify an actual performance improvement using the private evaluation protocol.
