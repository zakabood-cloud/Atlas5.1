# Multi-agent orchestration and research coverage

## General rule
A team should maximize **complementary verifiable evidence**, not headcount. Default to direct work for narrow tasks, subagents for isolated parallel assignments, agent teams only when supported/enabled and peer-to-peer coordination truly adds value. Never claim independent cross-model validation if all agents ran the same model or relied on one source.

## Work graph
Define each task as `{task_id, question, prerequisite_ids, evidence_needed, search_plan, assigned_role, tool_scope, output_path, expected_claims, validation_method, completion_rule, blocked_reason}`. Parallelize tasks with no dependencies. Every researcher writes to a unique directory and returns a summary and source IDs. Avoid simultaneous writes to shared central files. Orchestrator merges outputs after inspection.

## Recommended dynamic roles
- **Research Director:** objective, decision criteria, task DAG, branch assignment, coverage, synthesis, conflict resolution and gate enforcement. Does not claim verification of its own final claims.
- **Methodology Architect:** research-method search, scientific/professional standards, feasibility and bias assessment.
- **Source & Data Scout:** discover authoritative sources and datasets; record access and provenance.
- **Tool Architect:** verify official tool documentation, available MCPs and pilot tests; no unapproved installations.
- **Domain Researcher(s):** evidence gathering across defined segments/hypotheses/geographies/channels.
- **Quantitative Analyst:** independently construct and execute calculations, assumptions, error and sensitivity checks.
- **Counterevidence Investigator:** proactively seek failure cases and disconfirming studies/data.
- **Evidence Auditor:** audit claim/source mappings and numerical support; no unverified citations.
- **Synthesis Director:** conditional decisions after audit, report and deliverables.

## Independent-branch design
1. Predefine what each branch can see: common neutral question, scope and standards, but NOT other branches' premature conclusions.
2. Assign different evidence families, independent hypotheses or methods as feasible. Independent *agents* using duplicated primary data do not count as independent *evidence*.
3. Require every branch to output `claims`, `source_ids`, `uncertainty`, `contradictions`, `gaps`, `recommendation_conditioned_on_assumptions`.
4. Aggregate source provenance before any consensus. Audit the strongest disagreements and near-ties.
5. If external AI providers are unavailable, use distinct Claude subagent contexts and distinct source families; label validation as **same-model cross-check** not independent-model validation.

## Search coverage controls
- Build domain ontology and query matrix by concept, synonym, counterclaim, timeframe, language, geography, source type, stakeholder and outcomes.
- For each major candidate capture both supporting and opposing evidence and at least one direct look for failure evidence.
- Use backward and forward source chaining, original methodology appendix, official primary data, relevant archives and highly targeted source retrieval.
- Deduplicate by canonical document and **underlying information origin**; track syndicated media copies.
- Coverage = (evidence requirements sufficiently investigated)/(all predefined relevant requirements), with explicit weighting and unresolved gaps. Never present this as the literal percentage of all possible internet evidence.
- Discover novel dimensions iteratively; log additions and ensure they do not bias rankings toward already favored candidates.
- Use evidence saturation: marginal new independent sources, contradiction resolution, and likelihood of rank reversal.

## Budget orchestration
Allocate more calls to questions with high importance and uncertainty and where new evidence might change the decision. Cap excessive redundancy. Query freshness and tool reliability before expensive repeated calls. Stop a line of inquiry when no further feasible evidence would materially alter a decision under available resources; retain gaps.

## Failure and rollback
Timeout, invalid response, stale provider, permission denial, incomplete pagination, parsing ambiguity or agent crash => retry within approved limits, record attempts, try alternate source, and flag unresolved. Never fabricate an output to keep the DAG green. A task with zero evidence cannot be marked complete due to a well-written narrative.

## Model selection
Determine available model names and provider integrations **at runtime**. Do not freeze a vendor's latest model names into this long-lived file. Select models for measured retrieval/reasoning/data tasks based on user-accessible capabilities and a local benchmark. Reserve costly reasoning for methodology disputes, critical inference and audits. Document exact model/version where exposed by the runtime. External models are optional; never require inaccessible services to finish an appropriately downgraded investigation.
